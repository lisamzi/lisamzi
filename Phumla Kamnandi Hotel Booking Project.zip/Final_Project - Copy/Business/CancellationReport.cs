﻿using PhumlaKamnandiMockup.Data;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Windows.Forms;

namespace PhumlaKamnandiMockup.Business
{
    public class CancellationReport
    {
        public string BookingID { get; set; }
        public string ReasonForCancellation { get; set; }
        public DateTime CancellationDate { get; set; } // Ensure this property exists

        private string connectionString = Properties.Settings.Default.Phumla_KConnectionString;

        // Method to generate cancellation report for all cancellations
        public List<CancellationReport> GetAllCancellations()
        {
            List<CancellationReport> cancelledBookings = new List<CancellationReport>();

            // SQL Query to pull from Cancellation table
            string query = "SELECT BookingID, ReasonForCancellation, DateOfCancellation FROM Cancellation";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand(query, connection);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            CancellationReport report = new CancellationReport
                            {
                                BookingID = reader["BookingID"].ToString(),
                                ReasonForCancellation = reader["ReasonForCancellation"].ToString(),
                                CancellationDate = Convert.ToDateTime(reader["DateOfCancellation"])
                            };

                            cancelledBookings.Add(report);
                        }
                    }
                }
            }
            catch (SqlException sqlEx)
            {
                MessageBox.Show($"SQL Error: {sqlEx.Message}", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "General Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return cancelledBookings;
        }
        public void GenerateCancellationReport(ListView listView)
        {
            // Get all cancellations
            List<CancellationReport> cancellations = GetAllCancellations();

            // Display the cancellations in the ListView
            DisplayCancellationReport(cancellations, listView);
        }

        public void DisplayCancellationsInListView(ListView listView, List<CancellationReport> cancellations)
        {
            listView.Items.Clear(); // Clear any previous data

            foreach (var cancellation in cancellations)
            {
                ListViewItem item = new ListViewItem(cancellation.BookingID);
                item.SubItems.Add(cancellation.ReasonForCancellation);
                item.SubItems.Add(cancellation.CancellationDate.ToString("yyyy-MM-dd"));

                listView.Items.Add(item); // Add each cancellation to ListView
            }
        }


        // Method to display cancellation report in a ListView
        public void DisplayCancellationReport(List<CancellationReport> reportData, ListView listview)
        {
            listview.Items.Clear(); // Clear any previous data

            // Add all cancellation data to the ListView
            foreach (var report in reportData)
            {
                ListViewItem item = new ListViewItem(report.BookingID);
                item.SubItems.Add(report.ReasonForCancellation);
                item.SubItems.Add(report.CancellationDate.ToString("yyyy-MM-dd")); // Format the date

                listview.Items.Add(item); // Add the item to ListView
            }
        }
    }
}
