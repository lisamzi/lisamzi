﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhumlaKamnandiMockup.Business
{
    public class RoomAllocations
    {
        public string BookingRoomID { get; set; }  
        public string RoomID { get; set; }         
        public int GuestsInRoom { get; set; }      
        public int Adults { get; set; }            
        public int Children { get; set; }           
        public int Toddlers { get; set; }           

        public RoomAllocations(string bookingRoomID, string roomID, int guestsInRoom, int adults, int children, int toddlers)
         {
             BookingRoomID = bookingRoomID;
             RoomID = roomID;
             GuestsInRoom = guestsInRoom;
             Adults = adults;
             Children = children;
             Toddlers = toddlers;
         }
        

    }
}
