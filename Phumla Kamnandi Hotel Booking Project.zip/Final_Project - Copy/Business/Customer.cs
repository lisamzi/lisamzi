﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhumlaKamnandiMockup.Business
{
    public class Customer : Person
    {
        
        public string CustID { get; set; }
       // public string Name { get; set; }
        //public string Surname { get; set; }
        //public string Email { get; set; }
        //public string Phone { get; set; }
        //public string Address { get; set; }
        //public int Age { get; set; }

      
        public Customer(string custID, string name, string surname, string email, int age, string phone, string address)
            : base(name, surname, email, age, phone, address) 
        {
            CustID = custID;
            Name = name;
            Surname = surname;
            Email = email;
            Phone = phone;
            Address = address;
            Age = age;
        }

    }
}
