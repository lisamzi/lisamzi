﻿using Microsoft.SqlServer.Server;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhumlaKamnandiMockup.Business
{
    public class Receptionist
    {
        
        private string id = "123";
        private string password = "456";

        #region methods 
        // validate username/id

        public Boolean validateID(string inputID)
        {
            return id.Equals(inputID);
        }
        //validate password 
        public Boolean validatePassword(string inputPassword)
        {
            return password.Equals(inputPassword);
        }
        //constructor 
       
        // Default constructor
        public Receptionist()
            
        {
        }
        #endregion


    }
}
