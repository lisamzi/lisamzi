﻿using System;

public class OccupancyData
{
    public DateTime BookingDate { get; set; }  // The date of the booking (check-in date)
    public int TotalGuests { get; set; }       // Total number of guests for that date
}
