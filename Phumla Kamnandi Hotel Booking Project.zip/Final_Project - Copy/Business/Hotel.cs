﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhumlaKamnandiMockup.Business
{
    public class Hotel
    {
        
        public int HotelID;
        public string HotelName;
        public string Location;
        public int Capacity;
        public bool HasPool;
        public bool HasGym;
        public bool HasTennis;
        public bool HasHorse;
        public bool HasBowls;
        public bool GameRoom;

        public static Hotel GetHotelByID(int hotelID, List<Hotel> hotels)
        {
            foreach (Hotel hotel in hotels)
            {
                if (hotel.HotelID == hotelID) 
                {
                    return hotel; 
                }
            }
            return null; 
        }
       
        public List<string> GetAmenities()
        {
            List<string> amenities = new List<string>();

            if (HasPool) amenities.Add("Pool");
            if (HasGym) amenities.Add("Gym");
            if (HasTennis) amenities.Add("Tennis Court");
            if (HasHorse) amenities.Add("Horse Riding");
            if (HasBowls) amenities.Add("Bowls");
            if (GameRoom) amenities.Add("Game Room");

            return amenities;
        }
        // constructor 

        public Hotel(int hotelID, string hotelName, string location, int capacity,
                 bool hasPool, bool hasGym, bool hasTennis, bool hasHorse,
                 bool hasBowls, bool gameRoom)
        {
            HotelID = hotelID;
            HotelName = hotelName;
            Location = location;
            Capacity = capacity;
            HasPool = hasPool;
            HasGym = hasGym;
            HasTennis = hasTennis;
            HasHorse = hasHorse;
            HasBowls = hasBowls;
            GameRoom = gameRoom;
        }
    }
}
