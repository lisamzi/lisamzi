﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using PhumlaKamnandiMockup.Properties;


namespace PhumlaKamnandiMockup.Business
{
    public class OccupancyReport
    {
        private string connectionString = Properties.Settings.Default.Phumla_KConnectionString;

        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }

       
        public List<OccupancyData> ReportData { get; set; }


        
        public OccupancyReport()
        {
            ReportData = new List<OccupancyData>(); 
        }

        public List<OccupancyData> GenerateOccupancyReport(DateTime startDate, DateTime endDate)
        {
            
            if (startDate > endDate)
            {
                throw new ArgumentException("Start date must be less than or equal to end date.");
            }

            
            string query = @"
        SELECT 
            CheckInDate AS BookingDate, 
            SUM(NoOfGuests) AS TotalGuests
        FROM 
            Bookings 
        WHERE 
            Status = 'Confirmed' AND
            CheckInDate >= @StartDate AND 
            CheckInDate <= @EndDate
        GROUP BY 
            CheckInDate
        ORDER BY 
            CheckInDate";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@StartDate", startDate);
                    command.Parameters.AddWithValue("@EndDate", endDate);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.HasRows) 
                        {
                            while (reader.Read())
                            {
                                OccupancyData data = new OccupancyData
                                {
                                    BookingDate = reader.GetDateTime(0),
                                    TotalGuests = reader.GetInt32(1) 
                                };
                                ReportData.Add(data); 
                            }
                        }
                    }
                }
            }
            catch (SqlException sqlEx)
            {
                MessageBox.Show($"SQL Error: {sqlEx.Message}", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "General Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            
            return ReportData;
        }


        public void DisplayOccupancyReport(List<OccupancyData> reportData, ListView listview)
        {
            
            listview.Items.Clear();

            
            foreach (var report in reportData)
            {
                
                ListViewItem item = new ListViewItem(report.BookingDate.ToString("yyyy-MM-dd")); 
                item.SubItems.Add(report.TotalGuests.ToString()); 

                listview.Items.Add(item);
            }
            

            

        }
        //generate chart
        public void GenerateOccupancyChart(List<OccupancyData> reportData, Chart chart)
        {
           
            chart.Series.Clear();
            chart.Legends.Clear();

            Series series = new Series
            {
                Name = "Occupancy",
                Color = System.Drawing.Color.Green,
                IsValueShownAsLabel = true, 
                ChartType = SeriesChartType.Bar 
            };

            
            foreach (var item in reportData)
            {
                series.Points.AddXY(item.BookingDate.ToString("yyyy-MM-dd"), item.TotalGuests);
            }


            chart.Series.Add(series);
            chart.Titles.Clear();
            chart.Titles.Add("Occupancy Report");
            chart.ChartAreas[0].AxisX.Title = "Check-in Date";
            chart.ChartAreas[0].AxisY.Title = "Total Guests";


            
        }
    }
}
