﻿using PhumlaKamnandiMockup.Data;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
namespace PhumlaKamnandiMockup.Business
{
    public class Booking
    {
        private string connectionString = Properties.Settings.Default.Phumla_KConnectionString;

        public string BookingID { get; set; }
        public string CustID { get; set; }
        public string HotelID { get; set; }
        public DateTime CheckInDate { get; set; }
        public DateTime CheckOutDate { get; set; }
        public string Status { get; set; }
        public int adults { get; set; }
        public int children { get; set; }
        public int toddlers { get; set; }
        public int NoOfGuests {  get; set; }
        public int NoOfRooms { get; set; }
        public decimal TotalAmount { get; set; }
        public List<RoomAllocations> RoomAllocations { get; set; }

      
        public Booking()
        {
            RoomAllocations = new List<RoomAllocations>();
        }

        public Booking(string bookingID, string custID, string hotelID, DateTime checkInDate, DateTime checkOutDate, string status, int NoOfGuest, int noOfRooms, decimal total)
        { 
            BookingID = bookingID;
            CustID = custID;
            HotelID = hotelID;
            CheckInDate = checkInDate;
            CheckOutDate = checkOutDate;
            Status = status;
            NoOfGuests = NoOfGuest;
            NoOfRooms = noOfRooms;
            TotalAmount = total;
            
        }

        public static string GenerateBookingID()
        {
            string newBookingID = "B001";
            string connectionString = Properties.Settings.Default.Phumla_KConnectionString;
            string query = "SELECT MAX(BookingID) FROM Bookings WHERE BookingID LIKE 'B%'";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                object result = command.ExecuteScalar();

                if (result != DBNull.Value)
                {
                    string maxBookingID = result.ToString();
                    string numberPart = maxBookingID.Substring(1);
                    int number = int.Parse(numberPart);
                    number++;
                    newBookingID = "B" + number.ToString("D3");
                }
            }

            return newBookingID;
        }
    }
}


