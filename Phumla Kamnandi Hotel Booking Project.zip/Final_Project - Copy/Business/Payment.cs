﻿using Microsoft.SqlServer.Server;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhumlaKamnandiMockup.Business
{
    namespace PhumlaKamnandiMockup.Business
    {
        public class Payment
        {

            public string BookingID { get; set; }
            public double Price { get; private set; }
            public string Season { get; set; }


            //public Payment(string custID, string bookingID, decimal price, string season, string name, string surname, string email, int age, string phone, string address)
            //    : base(custID, name, surname, email, age, phone, address) 
            //{
            //    BookingID = bookingID;
            //    Price = price;
            //    Season = season;
            //}

            //default contructor
            public Payment()
            {

            }
            #region methods
            public double GetPrice(string season, int numberOfTotalGuests, int toddler, int child, int adult, int duration)
            {
                double totalPrice = 0;
                double basePrice = 0;


                switch (season)
                {
                    case "Low Season":
                        basePrice = 550;
                        break;
                    case "Mid Season":
                        basePrice = 750;
                        break;
                    case "High Season":
                        basePrice = 995;
                        break;
                    case "Normal Season":
                        basePrice = 450;
                        break;
                }

                // an adult staying alone
                if (adult == 1 && numberOfTotalGuests == 1)
                {

                    totalPrice = (basePrice / 2) + basePrice;
                }
                else
                {
                    //total price based on guests
                    totalPrice += adult * basePrice;
                    totalPrice += child * (basePrice / 2);
                    totalPrice += toddler * 0;
                }

                Price = totalPrice;
                return totalPrice * duration;
            }


            public string DetermineSeason(DateTime checkInDate)
            {
                // Check for December first
                if (checkInDate.Month == 12)
                {
                    if (checkInDate.Day >= 1 && checkInDate.Day <= 7)
                    {
                        return "Low Season";
                    }
                    else if (checkInDate.Day >= 8 && checkInDate.Day <= 15)
                    {
                        return "Mid Season";
                    }
                    else if (checkInDate.Day >= 16 && checkInDate.Day <= 31)
                    {
                        return "High Season";
                    }
                }

                // Default for all other months
                return "Normal Season";
            }
            #endregion
        }
    }
}





