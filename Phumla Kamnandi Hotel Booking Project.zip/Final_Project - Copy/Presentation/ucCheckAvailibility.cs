﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PhumlaKamnandiMockup.UserControls
{
    public partial class ucCheckAvailibility : UserControl
    {
        public ucCheckAvailibility()
        {
            InitializeComponent();
        }
        private void addUserControl(UserControl userControl)
        {
            userControl.Dock = DockStyle.Fill;
            panel1.Controls.Add(userControl); 
            userControl.BringToFront();
        }

        private void btnContinue_Click(object sender, EventArgs e)
        {

            //logic to check availability in database


            ucCheckAvailibility02 ucCheck = new ucCheckAvailibility02(this);
            addUserControl(ucCheck);
        }

        private void panel1Check_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}
