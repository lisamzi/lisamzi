﻿namespace PhumlaKamnandiMockup.UserControls_and_Forms
{
    partial class ucGenerateTable
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelGenerate = new System.Windows.Forms.Panel();
            this.GenTableListView = new System.Windows.Forms.ListView();
            this.btnBack = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnOccupancyReports = new System.Windows.Forms.Button();
            this.btnCancellationReports = new System.Windows.Forms.Button();
            this.dateTimeend = new System.Windows.Forms.DateTimePicker();
            this.dateTimestart = new System.Windows.Forms.DateTimePicker();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panelGenerate.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panelGenerate
            // 
            this.panelGenerate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panelGenerate.Controls.Add(this.pictureBox1);
            this.panelGenerate.Controls.Add(this.GenTableListView);
            this.panelGenerate.Controls.Add(this.btnBack);
            this.panelGenerate.Controls.Add(this.label2);
            this.panelGenerate.Controls.Add(this.label1);
            this.panelGenerate.Controls.Add(this.label4);
            this.panelGenerate.Controls.Add(this.label5);
            this.panelGenerate.Controls.Add(this.btnOccupancyReports);
            this.panelGenerate.Controls.Add(this.btnCancellationReports);
            this.panelGenerate.Controls.Add(this.dateTimeend);
            this.panelGenerate.Controls.Add(this.dateTimestart);
            this.panelGenerate.Location = new System.Drawing.Point(0, 0);
            this.panelGenerate.Name = "panelGenerate";
            this.panelGenerate.Size = new System.Drawing.Size(721, 529);
            this.panelGenerate.TabIndex = 2;
            this.panelGenerate.Paint += new System.Windows.Forms.PaintEventHandler(this.panelGenerate_Paint);
            // 
            // GenTableListView
            // 
            this.GenTableListView.HideSelection = false;
            this.GenTableListView.Location = new System.Drawing.Point(14, 138);
            this.GenTableListView.Name = "GenTableListView";
            this.GenTableListView.Size = new System.Drawing.Size(358, 334);
            this.GenTableListView.TabIndex = 51;
            this.GenTableListView.UseCompatibleStateImageBehavior = false;
            this.GenTableListView.SelectedIndexChanged += new System.EventHandler(this.GenTableListView_SelectedIndexChanged);
            // 
            // btnBack
            // 
            this.btnBack.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnBack.FlatAppearance.BorderSize = 0;
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnBack.Location = new System.Drawing.Point(11, 2);
            this.btnBack.Margin = new System.Windows.Forms.Padding(2);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(42, 33);
            this.btnBack.TabIndex = 50;
            this.btnBack.Text = "←";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label2.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(232, 85);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(91, 15);
            this.label2.TabIndex = 37;
            this.label2.Text = "Select end date:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label1.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(74, 84);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 15);
            this.label1.TabIndex = 36;
            this.label1.Text = "Select start date:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.Control;
            this.label4.Location = new System.Drawing.Point(60, 61);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(183, 15);
            this.label4.TabIndex = 35;
            this.label4.Text = "Please enter the following details:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(47, 29);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(184, 32);
            this.label5.TabIndex = 32;
            this.label5.Text = "Generate Table";
            // 
            // btnOccupancyReports
            // 
            this.btnOccupancyReports.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnOccupancyReports.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray;
            this.btnOccupancyReports.FlatAppearance.BorderSize = 0;
            this.btnOccupancyReports.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btnOccupancyReports.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnOccupancyReports.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOccupancyReports.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOccupancyReports.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnOccupancyReports.Location = new System.Drawing.Point(536, 36);
            this.btnOccupancyReports.Name = "btnOccupancyReports";
            this.btnOccupancyReports.Size = new System.Drawing.Size(146, 29);
            this.btnOccupancyReports.TabIndex = 31;
            this.btnOccupancyReports.Text = "Occupancy Reports";
            this.btnOccupancyReports.UseVisualStyleBackColor = false;
            this.btnOccupancyReports.Click += new System.EventHandler(this.btnOccupancyReports_Click);
            // 
            // btnCancellationReports
            // 
            this.btnCancellationReports.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnCancellationReports.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray;
            this.btnCancellationReports.FlatAppearance.BorderSize = 0;
            this.btnCancellationReports.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btnCancellationReports.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCancellationReports.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancellationReports.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancellationReports.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnCancellationReports.Location = new System.Drawing.Point(536, 74);
            this.btnCancellationReports.Name = "btnCancellationReports";
            this.btnCancellationReports.Size = new System.Drawing.Size(146, 29);
            this.btnCancellationReports.TabIndex = 30;
            this.btnCancellationReports.Text = "Cancellation Reports";
            this.btnCancellationReports.UseVisualStyleBackColor = false;
            this.btnCancellationReports.Click += new System.EventHandler(this.btnCancellationReports_Click);
            // 
            // dateTimeend
            // 
            this.dateTimeend.CalendarForeColor = System.Drawing.SystemColors.ButtonFace;
            this.dateTimeend.CalendarMonthBackground = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.dateTimeend.CalendarTitleBackColor = System.Drawing.SystemColors.ButtonFace;
            this.dateTimeend.CalendarTrailingForeColor = System.Drawing.SystemColors.Desktop;
            this.dateTimeend.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimeend.Location = new System.Drawing.Point(235, 102);
            this.dateTimeend.Name = "dateTimeend";
            this.dateTimeend.Size = new System.Drawing.Size(137, 21);
            this.dateTimeend.TabIndex = 1;
            // 
            // dateTimestart
            // 
            this.dateTimestart.CalendarForeColor = System.Drawing.SystemColors.ControlDark;
            this.dateTimestart.CalendarMonthBackground = System.Drawing.SystemColors.Menu;
            this.dateTimestart.CalendarTitleBackColor = System.Drawing.SystemColors.ButtonFace;
            this.dateTimestart.CalendarTitleForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.dateTimestart.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimestart.Location = new System.Drawing.Point(77, 102);
            this.dateTimestart.Name = "dateTimestart";
            this.dateTimestart.Size = new System.Drawing.Size(137, 21);
            this.dateTimestart.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Enabled = false;
            this.pictureBox1.Image = global::PhumlaKamnandiMockup.Properties.Resources.Cancellation_Table;
            this.pictureBox1.Location = new System.Drawing.Point(407, 138);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(302, 334);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 52;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Visible = false;
            // 
            // ucGenerateTable
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panelGenerate);
            this.Name = "ucGenerateTable";
            this.Size = new System.Drawing.Size(721, 529);
            this.panelGenerate.ResumeLayout(false);
            this.panelGenerate.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelGenerate;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnOccupancyReports;
        private System.Windows.Forms.Button btnCancellationReports;
        private System.Windows.Forms.DateTimePicker dateTimeend;
        private System.Windows.Forms.DateTimePicker dateTimestart;
        private System.Windows.Forms.ListView GenTableListView;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}
