﻿using PhumlaKamnandiMockup.Presentation;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PhumlaKamnandiMockup.UserControls
{
    public partial class ucBookings : UserControl
    {
        public ucBookings()
        {
            InitializeComponent();
        }
        private void addUserControl(UserControl userControl)
        {
            userControl.Dock = DockStyle.Fill;
            panelBookings.Controls.Clear();
            panelBookings.Controls.Add(userControl);
            userControl.BringToFront();
        }
      
        private void btnCreateBooking_Click(object sender, EventArgs e)
        {
            ucCreateBooking01 ucCreate = new ucCreateBooking01();
            addUserControl(ucCreate);
        }

        private void btnUpdateBooking_Click(object sender, EventArgs e)
        {
            ucUpdateBooking01 ucUpdate = new ucUpdateBooking01();
            addUserControl(ucUpdate);
        }

        private void btnViewBooking_Click(object sender, EventArgs e)
        {
            ucViewBooking01 ucView = new ucViewBooking01();
            addUserControl(ucView);
        }

        private void btnDeleteBooking_Click(object sender, EventArgs e)
        {

        }

        private void btnDeleteBooking_Click_1(object sender, EventArgs e)
        {
            ucDeleteBooking01 uc = new ucDeleteBooking01();
            addUserControl(uc);
        }

        private void btnViewAllBookings_Click(object sender, EventArgs e)
        {
            ucViewAllBookings uc = new ucViewAllBookings();
            addUserControl(uc);
        }
    }
}
