﻿using PhumlaKamnandiMockup.Business.PhumlaKamnandiMockup.Business;
using PhumlaKamnandiMockup.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PhumlaKamnandiMockup.UserControls
{
    public partial class ucCreateBooking01 : UserControl
    {
        public int Adults => (int)numOfAdults.Value;
        public int Children => (int)NoOfChildren.Value;
        public int Toddlers => (int)NoOfToddlers.Value;
        public string HotelID => GetHotelName.Text;
        public string CustID;
        public string status;
        
        public DateTime CheckInDate => dateTimeCheckIN.Value;
        public DateTime CheckOutDate => dateTimeCheckOut.Value;

        public int NoOfGuests => Adults + Children + Toddlers;
       // public int StayDuration => (CheckOutDate - CheckInDate).Days;
        public int RequiredRooms => CalculateRequiredRooms(NoOfGuests);
        public int TotalRooms => (int)totalRooms.Value;


        //CreateBooking createBooking = new CreateBooking(this, CustID, HotelID, CheckInDate, CheckOutDate, Status, NoOfGuests, Rooms);

        public ucCreateBooking01()
        {
            InitializeComponent();
        }

        private bool CheckRoomAvailability(int requiredRooms, DateTime checkIn, DateTime checkOut)
        {
            using (var connection = new SqlConnection("your_connection_string"))
            {
                connection.Open();
                string query = "SELECT COUNT(*) FROM Bookings WHERE CheckInDate < @CheckOut AND CheckOutDate > @CheckIn";
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@CheckOut", checkOut);
                    command.Parameters.AddWithValue("@CheckIn", checkIn);

                    int bookedRooms = (int)command.ExecuteScalar();
                    const int totalRooms = 20; // Assuming total number of rooms

                    return (bookedRooms + requiredRooms) <= totalRooms;
                }
            }
        }

        private bool ValidateBookingFields()
        {
            if (Adults < 1)
            {
                MessageBox.Show("At least one adult must be selected.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (CheckInDate.Date < DateTime.Now.Date)
            {
                MessageBox.Show("Check-in date must be in the future.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (CheckOutDate.Date <= CheckInDate.Date)
            {
                MessageBox.Show("Check-out date must be after the check-in date.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            if(GetHotelName.SelectedIndex == -1)
            {
                MessageBox.Show("Hotel ID not selected", "Validation Error" , MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            if (TotalRooms < 1)
            {
                MessageBox.Show("At least one room must be selected.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }


            return true;
        }

        private int CalculateRequiredRooms(int totalGuests)
        {
            return (int)Math.Ceiling((double)totalGuests / 4); // max 4 guests per room
        }

        //private decimal CalculateTotalPrice()
        //{
        //    const decimal pricePerRoom = 100m; // Assuming a fixed price per room
        //    return CalculateRequiredRooms(NoOfGuests) * pricePerRoom * StayDuration;
        //}

        private void addUserControl(UserControl userControl)
        {
            userControl.Dock = DockStyle.Fill;
            panel1.Controls.Add(userControl);
            userControl.BringToFront();
        }

        private void btnContinue_Click(object sender, EventArgs e)
        {
            // If the check-in date is between 25th December and 26th December, reject the booking
            if (CheckInDate.Date == new DateTime(CheckInDate.Year, 12, 25) || CheckInDate.Date == new DateTime(CheckInDate.Year, 12, 26))
            {
                MessageBox.Show("Bookings are not allowed for check-in dates on 25th or 26th December due to full capacity.",
                                "Booking Not Allowed",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
                return; // Exit the method without proceeding
            }

            // Validate booking fields
            if (!ValidateBookingFields())
            {
                return;
            }

            // Check room availability for the entire stay
            BookingsDB bookingDB = new BookingsDB();
            bool isAvailable = bookingDB.CheckRoomAvailability(RequiredRooms, CheckInDate, CheckOutDate);

            if (isAvailable)
            {
                // Pass required data to the next control
                CreateBooking ucCreateBooking02 = new CreateBooking(this, CustID, HotelID, CheckInDate, CheckOutDate, status, NoOfGuests, TotalRooms, Adults, Children, Toddlers);
                addUserControl(ucCreateBooking02);
            }
            else
            {
                MessageBox.Show("Not enough rooms available for the selected dates.",
                                "Room Availability",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Information);
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
                    }

        private void GetHotelName_SelectedIndexChanged(object sender, EventArgs e)
        {
            string hotelID = GetHotelName.Text;
            hotelID = HotelID;
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            ucBookings uc = new ucBookings();
            addUserControl(uc);
        }

        private void numOfAdults_ValueChanged(object sender, EventArgs e)
        {
            if (numOfAdults.Value > 20)
            {
                MessageBox.Show("Too many guests selected", "Error", MessageBoxButtons.OK);
                numOfAdults.Value = 0;
            }
          
        }

        private void NoOfChildren_ValueChanged(object sender, EventArgs e)
        {
            if (NoOfChildren.Value > 20)
            {
                MessageBox.Show("Too many guests selected", "Error", MessageBoxButtons.OK);
                NoOfChildren.Value = 0;
            }
        }

        private void NoOfToddlers_ValueChanged(object sender, EventArgs e)
        {

            if (NoOfToddlers.Value > 20)
            {
                MessageBox.Show("Too many guests selected", "Error", MessageBoxButtons.OK);
                NoOfToddlers.Value = 0;
            }
        }
    }
}





