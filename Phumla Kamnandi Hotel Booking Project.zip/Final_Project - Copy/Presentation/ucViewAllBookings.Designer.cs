﻿namespace PhumlaKamnandiMockup.Presentation
{
    partial class ucViewAllBookings
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelViewBookings = new System.Windows.Forms.Panel();
            this.gpbViewBookings = new System.Windows.Forms.GroupBox();
            this.listViewBookings = new System.Windows.Forms.ListView();
            this.label5 = new System.Windows.Forms.Label();
            this.btnDone = new System.Windows.Forms.Button();
            this.panelViewBookings.SuspendLayout();
            this.gpbViewBookings.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelViewBookings
            // 
            this.panelViewBookings.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panelViewBookings.Controls.Add(this.gpbViewBookings);
            this.panelViewBookings.Location = new System.Drawing.Point(0, 0);
            this.panelViewBookings.Margin = new System.Windows.Forms.Padding(2);
            this.panelViewBookings.Name = "panelViewBookings";
            this.panelViewBookings.Size = new System.Drawing.Size(721, 529);
            this.panelViewBookings.TabIndex = 2;
            this.panelViewBookings.Paint += new System.Windows.Forms.PaintEventHandler(this.panelViewGuests_Paint);
            // 
            // gpbViewBookings
            // 
            this.gpbViewBookings.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.gpbViewBookings.Controls.Add(this.listViewBookings);
            this.gpbViewBookings.Controls.Add(this.label5);
            this.gpbViewBookings.Controls.Add(this.btnDone);
            this.gpbViewBookings.Location = new System.Drawing.Point(20, 17);
            this.gpbViewBookings.Name = "gpbViewBookings";
            this.gpbViewBookings.Size = new System.Drawing.Size(677, 488);
            this.gpbViewBookings.TabIndex = 4;
            this.gpbViewBookings.TabStop = false;
            // 
            // listViewBookings
            // 
            this.listViewBookings.HideSelection = false;
            this.listViewBookings.Location = new System.Drawing.Point(24, 82);
            this.listViewBookings.Name = "listViewBookings";
            this.listViewBookings.Size = new System.Drawing.Size(627, 328);
            this.listViewBookings.TabIndex = 7;
            this.listViewBookings.UseCompatibleStateImageBehavior = false;
            this.listViewBookings.SelectedIndexChanged += new System.EventHandler(this.listViewGuest_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI Semibold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(19, 29);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(153, 30);
            this.label5.TabIndex = 4;
            this.label5.Text = "View Bookings";
            // 
            // btnDone
            // 
            this.btnDone.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnDone.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray;
            this.btnDone.FlatAppearance.BorderSize = 0;
            this.btnDone.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btnDone.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnDone.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDone.Font = new System.Drawing.Font("Segoe UI Light", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDone.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnDone.Location = new System.Drawing.Point(24, 436);
            this.btnDone.Name = "btnDone";
            this.btnDone.Size = new System.Drawing.Size(108, 29);
            this.btnDone.TabIndex = 6;
            this.btnDone.Text = "Done";
            this.btnDone.UseVisualStyleBackColor = false;
            this.btnDone.Click += new System.EventHandler(this.btnDone_Click);
            // 
            // ucViewAllBookings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panelViewBookings);
            this.Name = "ucViewAllBookings";
            this.Size = new System.Drawing.Size(721, 529);
            this.panelViewBookings.ResumeLayout(false);
            this.gpbViewBookings.ResumeLayout(false);
            this.gpbViewBookings.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelViewBookings;
        private System.Windows.Forms.GroupBox gpbViewBookings;
        private System.Windows.Forms.ListView listViewBookings;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnDone;
    }
}
