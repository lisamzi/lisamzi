﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using PhumlaKamnandiMockup.Business;
using PhumlaKamnandiMockup.Data;


namespace PhumlaKamnandiMockup.UserControls
{
    public partial class ucCreateGuestProfile01 : UserControl
    {
        private static int idCounter = 1;

        public ucCreateGuestProfile01()
        {
            InitializeComponent();
        }

        private string GenerateGuestID(string firstName, string lastName)
        {
            if (string.IsNullOrWhiteSpace(firstName) || string.IsNullOrWhiteSpace(lastName))
            {
                throw new ArgumentException("First name and last name must not be empty.");
            }

            string firstPart = firstName.Substring(0, Math.Min(2, firstName.Length)).ToLower();
            string lastInitial = lastName.Substring(0, 1).ToLower();
            char lastLetter = lastName[lastName.Length - 1];

            string guestID = $"{firstPart}{lastInitial}{char.ToUpper(lastLetter)}{idCounter:D3}";

            idCounter++;

            return guestID;
        }

       
        private int CalculateAge(DateTime dateOfBirth)
        {
            int age = DateTime.Now.Year - dateOfBirth.Year;
            if (DateTime.Now.DayOfYear < dateOfBirth.DayOfYear)
            {
                age--;
            }
            return age;
        }

       
        private bool ValidateFields()
        {
            if (string.IsNullOrWhiteSpace(txtFirstName.Text))
            {
                MessageBox.Show("First name is required.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            if (string.IsNullOrWhiteSpace(txtLastName.Text))
            {
                MessageBox.Show("Last name is required.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            if (string.IsNullOrWhiteSpace(txtEmail.Text))
            {
                MessageBox.Show("Email is required.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            if (string.IsNullOrWhiteSpace(txtPhoneNum.Text))
            {
                MessageBox.Show("Phone number is required.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            if (string.IsNullOrWhiteSpace(txtAddress.Text))
            {
                MessageBox.Show("Address is required.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            return true;
        }


        private void btnCreateProfile_Click(object sender, EventArgs e)
        {
            if (!ValidateFields())
            {
                return;
            }

            string firstName = txtFirstName.Text;
            string lastName = txtLastName.Text;
            string email = txtEmail.Text;
            string phone = txtPhoneNum.Text;
            string address = txtAddress.Text;
            DateTime dateOfBirth = dtDateOfBirth.Value;
            int age = CalculateAge(dateOfBirth);

            try
            {
                
                CustomerDB customerDb = new CustomerDB();
                string custID = customerDb.GenerateCustID(firstName + " " + lastName);

                
                Customer newCustomer = new Customer(custID, firstName, lastName, email, age, phone, address);

               
                customerDb.SaveGuest(newCustomer);

                MessageBox.Show("Guest profile " + custID + " has been successfully created and saved to the database.", "Success", MessageBoxButtons.OK);

                
                ucGuests uc = new ucGuests();
                this.Controls.Remove(panel1);
                this.Controls.Add(uc);
                uc.Dock = DockStyle.Fill;
                uc.BringToFront();

            }
            catch (ArgumentException ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Database error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }



        private void dtDateOfBirth_ValueChanged(object sender, EventArgs e)
        {

        }

        private void txtFirstName_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtLastName_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtEmail_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtPhoneNum_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtAddress_TextChanged(object sender, EventArgs e)
        {

        }
        private void addUserControl(UserControl userControl)
        {
            userControl.Dock = DockStyle.Fill;
            panel1.Controls.Clear();
            panel1.Controls.Add(userControl);
            userControl.BringToFront();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Controls.Remove(panel1);
            ucGuests uc = new ucGuests();
            this.Controls.Add(uc);
            uc.Dock = DockStyle.Fill;
            uc.BringToFront();
        }

        private void gpbCreateGuestProfile_Enter(object sender, EventArgs e)
        {

        }
    }
}


