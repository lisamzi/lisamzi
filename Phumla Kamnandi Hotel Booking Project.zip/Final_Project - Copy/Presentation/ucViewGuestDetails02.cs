﻿using PhumlaKamnandiMockup.Business;
using PhumlaKamnandiMockup.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PhumlaKamnandiMockup.UserControls
{
    public partial class ucViewGuestDetails02 : UserControl
    {
        public Customer GuestID;
        public string GuestName;
        public string GuestLName;
        public string address;
        public string email;
        public int number;
        public Booking pastbooking;
        public Booking futureBooking;
        public ucViewGuestDetails02(Customer guest)
        {
            InitializeComponent();
            LoadGuestDetails(guest);
        }


        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnDeleteGuest_Click(object sender, EventArgs e)
        {
            // Confirm deletion with the user
            DialogResult result = MessageBox.Show("Are you sure you want to delete guest " + lblGuestID.Text + "?", "Delete Guest", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                // Create an instance of CustomerDB
                CustomerDB customerDB = new CustomerDB();

                // Call the DeleteGuest method
                customerDB.DeleteGuest(lblGuestID.Text);

                // Notify the user of successful deletion
                MessageBox.Show("Guest " + lblGuestID.Text + " has been successfully deleted.",
                                "Guest Deleted",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Information);
            }
        }

        private void btnEditGuest_Click(object sender, EventArgs e)
        {
            txtName.ReadOnly= false;
            txtSurname.ReadOnly= false;
            txtAddress.ReadOnly= false;
            txtEmail.ReadOnly= false;
            txtContactNo.ReadOnly= false;
           

            btnUpdateGuest.Enabled = true;

        }

        private void gpbViewBooking_Enter(object sender, EventArgs e)
        {

        }
        private void LoadGuestDetails(Customer guest)
        {
            
            lblGuestID.Text = guest.CustID;
            txtName.Text = guest.Name; 
            txtEmail.Text = guest.Email; 
            txtContactNo.Text = guest.Phone;
            txtAddress.Text = guest.Address;
            txtSurname.Text = guest.Surname;
        }

        private void btnDone_Click(object sender, EventArgs e)
        {
            this.Controls.Remove(panel1);
            ucGuests uc = new ucGuests();
            this.Controls.Add(uc);
            uc.Dock = DockStyle.Fill;
            uc.BringToFront();
        }
        private int CalculateAge(DateTime dateOfBirth)
        {
            int age = DateTime.Now.Year - dateOfBirth.Year;
            if (DateTime.Now.DayOfYear < dateOfBirth.DayOfYear)
            {
                age--;
            }
            return age;
        }
        private void btnUpdateGuest_Click(object sender, EventArgs e)
        {

            
            btnUpdateGuest.Enabled = false;
            DateTime dateOfBirth = dtDOB.Value;
            int age = CalculateAge(dateOfBirth);
            

            
            string custID = lblGuestID.Text; 
            string name = txtName.Text;
            string surname = txtSurname.Text;
            string email = txtEmail.Text;
            string phone = txtContactNo.Text;
            string address = txtAddress.Text;
            

            if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(surname) ||
    string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(phone) ||
    string.IsNullOrWhiteSpace(address))
            {
                MessageBox.Show("All fields must be filled in.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                btnUpdateGuest.Enabled = true; 
                return;
            }


            
            Customer updatedGuest = new Customer(custID, name, surname, email, age, phone, address); 

            CustomerDB customerDB = new CustomerDB();
            customerDB.UpdateGuest(updatedGuest);

            MessageBox.Show("Guest information has been successfully updated.", "Update Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);
            txtName.ReadOnly = true;
            txtSurname.ReadOnly = true;
            txtAddress.ReadOnly = true;
            txtEmail.ReadOnly = true;
            txtContactNo.ReadOnly = true;
          

            btnUpdateGuest.Enabled = false; 


        }


        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Controls.Remove(panel1);
            ucViewGuestDetails uc = new ucViewGuestDetails();
            this.Controls.Add(uc);
            uc.Dock = DockStyle.Fill;
            uc.BringToFront();
        }

        private void txtGuestID_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblGuestID_Click(object sender, EventArgs e)
        {
            
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
