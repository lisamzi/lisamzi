﻿using PhumlaKamnandiMockup.Business;
using PhumlaKamnandiMockup.UserControls;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace PhumlaKamnandiMockup
{
    public partial class LogIn : Form
    {

        public LogIn()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e) { }

        private void label5_Click(object sender, EventArgs e) { }

        private void btnShow_Click(object sender, EventArgs e)
        {

            if (txtPasswordLogIn.PasswordChar == '*')
            {

                txtPasswordLogIn.PasswordChar = '\0';
                btnShow.Text = "👁Hide";
            }
            else
            {

                txtPasswordLogIn.PasswordChar = '*';
                btnShow.Text = "👁Show";
            }
        }

        private void btnLogIn_Click(object sender, EventArgs e)
        {
            ////check if id is entered
            if (string.IsNullOrWhiteSpace(txtID.Text))
            {
                MessageBox.Show("Please enter your Employee ID.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (string.IsNullOrWhiteSpace(txtPasswordLogIn.Text))
            {
                MessageBox.Show("Please enter your password.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            // Get the input from text boxes
            string inputID = txtID.Text; // Assuming you have a TextBox named txtID
            string inputPassword = txtPasswordLogIn.Text; // Assuming you have a TextBox named txtPassword

            // Create an instance of the Receptionist class
            Receptionist receptionist = new Receptionist();

            // Validate ID and password
            if (receptionist.validateID(inputID) && receptionist.validatePassword(inputPassword))
            {
                // Login successful
                MessageBox.Show("Login successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Open homepage if successful
                SecondFormcs homepage = new SecondFormcs();
                this.Hide(); // Hide the current form
                homepage.ShowDialog(); // Show the homepage
            }
            else
            {
                // Login failed
                MessageBox.Show("Invalid ID or password. Please try again.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }






        } } }

