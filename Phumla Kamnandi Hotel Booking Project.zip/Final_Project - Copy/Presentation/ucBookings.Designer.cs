﻿namespace PhumlaKamnandiMockup.UserControls
{
    partial class ucBookings
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelBookings = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnViewBooking = new System.Windows.Forms.Button();
            this.btnCreateBooking = new System.Windows.Forms.Button();
            this.btnUpdateBooking = new System.Windows.Forms.Button();
            this.btnViewAllBookings = new System.Windows.Forms.Button();
            this.btnDeleteBooking = new System.Windows.Forms.Button();
            this.panelBookings.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelBookings
            // 
            this.panelBookings.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panelBookings.Controls.Add(this.groupBox1);
            this.panelBookings.Location = new System.Drawing.Point(0, 0);
            this.panelBookings.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panelBookings.Name = "panelBookings";
            this.panelBookings.Size = new System.Drawing.Size(721, 529);
            this.panelBookings.TabIndex = 3;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnDeleteBooking);
            this.groupBox1.Controls.Add(this.btnViewAllBookings);
            this.groupBox1.Controls.Add(this.btnViewBooking);
            this.groupBox1.Controls.Add(this.btnCreateBooking);
            this.groupBox1.Controls.Add(this.btnUpdateBooking);
            this.groupBox1.Location = new System.Drawing.Point(19, 20);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(684, 290);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            // 
            // btnViewBooking
            // 
            this.btnViewBooking.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnViewBooking.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnViewBooking.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnViewBooking.FlatAppearance.MouseOverBackColor = System.Drawing.Color.CornflowerBlue;
            this.btnViewBooking.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnViewBooking.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewBooking.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnViewBooking.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnViewBooking.Location = new System.Drawing.Point(20, 123);
            this.btnViewBooking.Name = "btnViewBooking";
            this.btnViewBooking.Size = new System.Drawing.Size(168, 42);
            this.btnViewBooking.TabIndex = 9;
            this.btnViewBooking.Text = "View Booking";
            this.btnViewBooking.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnViewBooking.UseVisualStyleBackColor = false;
            this.btnViewBooking.Click += new System.EventHandler(this.btnViewBooking_Click);
            // 
            // btnCreateBooking
            // 
            this.btnCreateBooking.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnCreateBooking.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnCreateBooking.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnCreateBooking.FlatAppearance.MouseOverBackColor = System.Drawing.Color.CornflowerBlue;
            this.btnCreateBooking.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCreateBooking.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCreateBooking.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnCreateBooking.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnCreateBooking.Location = new System.Drawing.Point(20, 28);
            this.btnCreateBooking.Name = "btnCreateBooking";
            this.btnCreateBooking.Size = new System.Drawing.Size(168, 43);
            this.btnCreateBooking.TabIndex = 6;
            this.btnCreateBooking.Text = "Create Booking";
            this.btnCreateBooking.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCreateBooking.UseVisualStyleBackColor = false;
            this.btnCreateBooking.Click += new System.EventHandler(this.btnCreateBooking_Click);
            // 
            // btnUpdateBooking
            // 
            this.btnUpdateBooking.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnUpdateBooking.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnUpdateBooking.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnUpdateBooking.FlatAppearance.MouseOverBackColor = System.Drawing.Color.CornflowerBlue;
            this.btnUpdateBooking.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUpdateBooking.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateBooking.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnUpdateBooking.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnUpdateBooking.Location = new System.Drawing.Point(20, 77);
            this.btnUpdateBooking.Name = "btnUpdateBooking";
            this.btnUpdateBooking.Size = new System.Drawing.Size(168, 40);
            this.btnUpdateBooking.TabIndex = 7;
            this.btnUpdateBooking.Text = "Update Booking";
            this.btnUpdateBooking.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnUpdateBooking.UseVisualStyleBackColor = false;
            this.btnUpdateBooking.Click += new System.EventHandler(this.btnUpdateBooking_Click);
            // 
            // btnViewAllBookings
            // 
            this.btnViewAllBookings.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnViewAllBookings.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnViewAllBookings.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnViewAllBookings.FlatAppearance.MouseOverBackColor = System.Drawing.Color.CornflowerBlue;
            this.btnViewAllBookings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnViewAllBookings.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewAllBookings.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnViewAllBookings.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnViewAllBookings.Location = new System.Drawing.Point(20, 171);
            this.btnViewAllBookings.Name = "btnViewAllBookings";
            this.btnViewAllBookings.Size = new System.Drawing.Size(168, 43);
            this.btnViewAllBookings.TabIndex = 10;
            this.btnViewAllBookings.Text = "View All Bookings";
            this.btnViewAllBookings.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnViewAllBookings.UseVisualStyleBackColor = false;
            this.btnViewAllBookings.Click += new System.EventHandler(this.btnViewAllBookings_Click);
            // 
            // btnDeleteBooking
            // 
            this.btnDeleteBooking.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnDeleteBooking.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnDeleteBooking.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnDeleteBooking.FlatAppearance.MouseOverBackColor = System.Drawing.Color.CornflowerBlue;
            this.btnDeleteBooking.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDeleteBooking.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteBooking.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnDeleteBooking.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnDeleteBooking.Location = new System.Drawing.Point(20, 220);
            this.btnDeleteBooking.Name = "btnDeleteBooking";
            this.btnDeleteBooking.Size = new System.Drawing.Size(168, 40);
            this.btnDeleteBooking.TabIndex = 11;
            this.btnDeleteBooking.Text = "Delete Booking";
            this.btnDeleteBooking.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDeleteBooking.UseVisualStyleBackColor = false;
            this.btnDeleteBooking.Click += new System.EventHandler(this.btnDeleteBooking_Click_1);
            // 
            // ucBookings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panelBookings);
            this.Name = "ucBookings";
            this.Size = new System.Drawing.Size(721, 529);
            this.panelBookings.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelBookings;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnViewBooking;
        private System.Windows.Forms.Button btnCreateBooking;
        private System.Windows.Forms.Button btnUpdateBooking;
        private System.Windows.Forms.Button btnViewAllBookings;
        private System.Windows.Forms.Button btnDeleteBooking;
    }
}
