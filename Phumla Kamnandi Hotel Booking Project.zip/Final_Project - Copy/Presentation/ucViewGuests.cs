﻿using PhumlaKamnandiMockup.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace PhumlaKamnandiMockup.UserControls
{
    public partial class ucViewGuests : UserControl
    {
        private CustomerDB _customerDB; 

        public ucViewGuests()
        {
            InitializeComponent();
            ConfigureListView();    
            _customerDB = new CustomerDB(); 
            LoadGuests(); 
        }
        
        private void ConfigureListView()
        {
            listViewGuest.View = View.Details; 
            listViewGuest.Columns.Clear(); 
            listViewGuest.Columns.Add("CustID", 100); 
            listViewGuest.Columns.Add("Name", 100); 
            listViewGuest.Columns.Add("Surname", 100); 
            listViewGuest.Columns.Add("Email", 150); 
            listViewGuest.Columns.Add("Phone", 100); 
            listViewGuest.Columns.Add("Address", 150); 
            listViewGuest.Columns.Add("Age", 50); 
        }

        private void LoadGuests()
        {
            
            listViewGuest.Items.Clear();

            
            var guests = _customerDB.GetAllGuests();

            
            foreach (var guest in guests)
            {
                ListViewItem item = new ListViewItem(guest.CustID); 
                item.SubItems.Add(guest.Name);
                item.SubItems.Add(guest.Surname);
                item.SubItems.Add(guest.Email);
                item.SubItems.Add(guest.Phone);
                item.SubItems.Add(guest.Address);
                item.SubItems.Add(guest.Age.ToString());

                listViewGuest.Items.Add(item); 
            }
        }


        private void btnDone_Click(object sender, EventArgs e)
        {
            this.Controls.Remove(panelViewGuests);
            ucGuests uc = new ucGuests();
            this.Controls.Add(uc);
            uc.Dock = DockStyle.Fill;
            uc.BringToFront();
        }

        private void gpbCreateGuestProfile_Enter(object sender, EventArgs e)
        {
            
        }

        private void listViewGuest_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }
    }
}
