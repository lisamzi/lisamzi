﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PhumlaKamnandiMockup.UserControls
{
    public partial class ucUpdateBooking01 : UserControl
    {
        public string bookingID;
        public ucUpdateBooking01()
        {
            InitializeComponent();
        }

        private void addUserControl(UserControl userControl)
        {
            userControl.Dock = DockStyle.Fill;
            panel1.Controls.Clear();
            panel1.Controls.Add(userControl);
            userControl.BringToFront();
        }

        private bool IsValidBookingID(string bookingID)
        {
            
            if (string.IsNullOrWhiteSpace(bookingID))
            {
                return false; 
            }

            return true;
        }

        private void btnContinue_Click(object sender, EventArgs e)
        {
            //validation
            string bookingID = txtBookingID.Text;

            if (!IsValidBookingID(bookingID))
            {
                MessageBox.Show("Please enter a valid Booking ID. It should be at least 5 characters long and alphanumeric.",
                                "Invalid Booking ID", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            
            bool bookingExists = FindBookingInDatabase(bookingID);

            if (!bookingExists)
            {
                MessageBox.Show("No booking found with the provided Booking ID. Please try again.",
                                "Booking Not Found", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return; 
            }

            txtBookingID.Text = bookingID;
            ucUpdateBooking02 uc = new ucUpdateBooking02(this, bookingID);
            addUserControl(uc);

           
        }

        private bool FindBookingInDatabase(string bookingID)
        {
          

            return true; // Assume it's found for now
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Controls.Remove(panel1);
            ucBookings uc = new ucBookings();
            this.Controls.Add(uc);
            uc.Dock = DockStyle.Fill;
            uc.BringToFront();
        }
     

        private void txtBookingID_TextChanged(object sender, EventArgs e)
        {
            //validate booking ID
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}

