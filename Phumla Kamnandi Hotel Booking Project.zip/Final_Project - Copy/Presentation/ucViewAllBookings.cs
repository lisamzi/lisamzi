﻿using PhumlaKamnandiMockup.Data;
using PhumlaKamnandiMockup.UserControls;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PhumlaKamnandiMockup.Presentation
{
    public partial class ucViewAllBookings : UserControl
    {
        private BookingsDB bookingsDb;

        public ucViewAllBookings()
        {
            InitializeComponent();

            
            bookingsDb = new BookingsDB();

            if (listViewBookings == null)
            {
                listViewBookings = new ListView();
                this.Controls.Add(listViewBookings);
            }

            listViewBookings.View = View.Details;
            listViewBookings.Columns.Add("Booking ID", 100);
            listViewBookings.Columns.Add("Customer ID", 100);
            listViewBookings.Columns.Add("Hotel ID", 100);
            listViewBookings.Columns.Add("Check-In Date", 100);
            listViewBookings.Columns.Add("Check-Out Date", 100);
            listViewBookings.Columns.Add("Status", 100);
            listViewBookings.Columns.Add("Guests", 100);
            listViewBookings.Columns.Add("Rooms", 100);
            listViewBookings.Columns.Add("Total Amount", 100);

            
            LoadBookings();
        }

        private void LoadBookings()
        {
            
            if (bookingsDb == null)
            {
                MessageBox.Show("bookingsDb is not initialized!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            var bookings = bookingsDb.GetAllBookings();

            listViewBookings.Items.Clear();  

            foreach (var booking in bookings)
            {
                ListViewItem item = new ListViewItem(booking.BookingID);
                item.SubItems.Add(booking.CustID);
                item.SubItems.Add(booking.HotelID);
                item.SubItems.Add(booking.CheckInDate.ToShortDateString());
                item.SubItems.Add(booking.CheckOutDate.ToShortDateString());
                item.SubItems.Add(booking.Status);
                item.SubItems.Add(booking.NoOfGuests.ToString());
                item.SubItems.Add(booking.NoOfRooms.ToString());
                item.SubItems.Add(booking.TotalAmount.ToString("C")); 

                listViewBookings.Items.Add(item);
            }
        }

        private void listViewGuest_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void panelViewGuests_Paint(object sender, PaintEventArgs e)
        {

        }
        private void addUserControl02(UserControl userControl)
        {
            userControl.Dock = DockStyle.Fill;
            panelViewBookings.Controls.Clear();
            panelViewBookings.Controls.Add(userControl);
            userControl.BringToFront();
        }
        
        private void btnDone_Click(object sender, EventArgs e)
        {
            ucBookings uc = new ucBookings();
            addUserControl02(uc);
        }
    }
}

