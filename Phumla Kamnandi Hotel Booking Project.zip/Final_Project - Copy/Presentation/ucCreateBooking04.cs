﻿using PhumlaKamnandiMockup.Business;
using PhumlaKamnandiMockup.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PhumlaKamnandiMockup.UserControls
{
    public partial class ucCreateBooking04 : UserControl
    {
        private ucCreateBooking03 previousControl;
        public string CustID;
        public DateTime CheckIn;
        public DateTime CheckOut;
        public int TotalRooms;
        public int Duration;
        public decimal Amount;
        public int Adults;      
        public int Children;   
        public int Toddlers;    


        public int TotalGuests;
        public string HotelID;
        public ucCreateBooking04(ucCreateBooking03 prevControl, string hotelID, string custID, DateTime checkInDate, DateTime checkOutDate, int noOfGuests, int totalRooms, int adults, int children, int toddlers, decimal total)
        {
            InitializeComponent();
            previousControl = prevControl;
            Amount = total;
            CustID = custID;
            CheckIn = checkInDate;
            CheckOut = checkOutDate;
            HotelID = hotelID;
            TotalGuests = noOfGuests;
            TotalRooms = totalRooms;
            Adults = adults;          
            Children = children;     
            Toddlers = toddlers;      
        }


        private void addUserControl(UserControl userControl)
        {
            userControl.Dock = DockStyle.Fill;
            panel1.Controls.Add(userControl);
            userControl.BringToFront();
        }

        private bool IsValidEmail(string email)
        {
            
            var emailPattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
            return System.Text.RegularExpressions.Regex.IsMatch(email, emailPattern);
        }

        private void btnEmailInvoice_Click(object sender, EventArgs e)
        {
            //check to see if email is valid
            if (string.IsNullOrWhiteSpace(txtPayerEmail.Text))
            {
                MessageBox.Show("Please enter an email address.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!IsValidEmail(txtPayerEmail.Text))
            {
                MessageBox.Show("Please enter a valid email address.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            
            //BookingsDB bookingsDB = new BookingsDB();


            //Booking newBooking = new Booking(
            //    Booking.GenerateBookingID(),
            //    CustID,
            //    HotelID,
            //    CheckIn,
            //    CheckOut,
            //    "Reserved",
            //    TotalGuests
            //);

            //try
            //{
            //    bookingsDB.AddBooking(newBooking);
            //    MessageBox.Show($"An invoice has been sent to {txtPayerEmail.Text}. Please ensure they pay the deposit in the next 48 hours to secure their booking.", "Booking reserved", MessageBoxButtons.OK);
            //    txtPayerEmail.Clear(); 
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show($"An error occurred while saving the booking: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //    return;
            //}

            this.Controls.Remove(panel1);
            ucHome home = new ucHome();
            this.Controls.Add(home);
            home.Dock = DockStyle.Fill;
            home.BringToFront();
        }




        private void panel2_Paint(object sender, PaintEventArgs e) { }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            previousControl.Show();
            previousControl.BringToFront();
        }

        private void addUserControl02(UserControl userControl)
        {
            userControl.Dock = DockStyle.Fill;
            panel1.Controls.Clear();
            panel1.Controls.Add(userControl);
            userControl.BringToFront();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            //cancel button does not delete booking but only closes the user control
            ucBookings ucBookings = new ucBookings();
            addUserControl02(ucBookings);
        }

        private void txtPayerEmail_MaskInputRejected(object sender, MaskInputRejectedEventArgs e) { }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {

            BookingsDB bookingsDB = new BookingsDB();

            Booking newBooking = new Booking(
                Booking.GenerateBookingID(),
                CustID,
                HotelID,
                CheckIn,
                CheckOut,
                "Confirmed",
                TotalGuests,
                TotalRooms,
                Amount
            );

            try
            {
                string bookingID = bookingsDB.AddBooking(newBooking); // Capture the returned BookingID
                MessageBox.Show($"Please ensure they pay the deposit in the next 48 hours to secure their booking. Your Booking ID is: {bookingID}",
                                "Booking reserved",
                                MessageBoxButtons.OK);
                txtPayerEmail.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while saving the booking: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            this.Controls.Remove(panel1);
            ucBookings home = new ucBookings();
            this.Controls.Add(home);
            home.Dock = DockStyle.Fill;
            home.BringToFront();
        }

        }
    }
    


