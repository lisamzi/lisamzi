﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PhumlaKamnandiMockup.UserControls
{
    public partial class ucGuests : UserControl
    {
        public ucGuests()
        {
            InitializeComponent();
        }
        private void addUserControl(UserControl userControl)
        {
            userControl.Dock = DockStyle.Fill;
            panelGuests.Controls.Clear();
            panelGuests.Controls.Add(userControl);
            userControl.BringToFront();
        }
       

        private void btnCreateGuestProfile_Click(object sender, EventArgs e)
        {
            ucCreateGuestProfile01 uc = new ucCreateGuestProfile01();
            addUserControl(uc);
        }

        private void btnViewGuestDetails_Click(object sender, EventArgs e)
        {
            ucViewGuestDetails ucViewGuestDetails0 = new ucViewGuestDetails();
            addUserControl(ucViewGuestDetails0);
        }

        

        private void btnViewGuests_Click(object sender, EventArgs e)
        {
            ucViewGuests ucViewGuests = new ucViewGuests();
            addUserControl(ucViewGuests);
        }

    }
}
