﻿using PhumlaKamnandiMockup.UserControls_and_Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PhumlaKamnandiMockup.UserControls
{
    public partial class ucGenerateReport01 : UserControl
    {
        public ucGenerateReport01()
        {
            InitializeComponent();
        }

      

        private void panelGenerate_Paint(object sender, PaintEventArgs e)
        {

        }
        private void addUserControl02(UserControl userControl)
        {
            userControl.Dock = DockStyle.Fill;
            panelGenerate.Controls.Clear();
            panelGenerate.Controls.Add(userControl);
            userControl.BringToFront();
        }
        private void btnGenerateTable_Click(object sender, EventArgs e)
        {
            ucGenerateTable uc = new ucGenerateTable();
            addUserControl02(uc);
        }

        private void btnGenerateChart_Click(object sender, EventArgs e)
        {
            ucGenerateChart uc = new ucGenerateChart();
            addUserControl02(uc);
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
