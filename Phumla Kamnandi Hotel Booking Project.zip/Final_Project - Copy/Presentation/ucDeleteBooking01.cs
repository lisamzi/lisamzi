﻿using PhumlaKamnandiMockup.Data;
using PhumlaKamnandiMockup.UserControls;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PhumlaKamnandiMockup.Presentation
{
    public partial class ucDeleteBooking01 : UserControl
    {
        string bookingID;
        string cancellationReason;
        
        public ucDeleteBooking01()
        {
            InitializeComponent();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Controls.Remove(panel1);
            ucBookings uc = new ucBookings();
            this.Controls.Add(uc);
            uc.Dock = DockStyle.Fill;
            uc.BringToFront();
        }
        private void addUserControl(UserControl userControl)
        {
            userControl.Dock = DockStyle.Fill;
            panel1.Controls.Clear();
            panel1.Controls.Add(userControl);
            userControl.BringToFront();
        }
       
        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void btnContinue_Click_1(object sender, EventArgs e)
        {
            bookingID = txtBookingID.Text;
            cancellationReason = comboBox1.Text;

            
            DialogResult result = MessageBox.Show("Are you sure you want to cancel the booking?",
                                                  "Confirm Cancellation",
                                                  MessageBoxButtons.YesNo,
                                                  MessageBoxIcon.Warning);

            
            if (result == DialogResult.Yes)
            {
                DateTime canceldate = DateTime.Now;
                BookingsDB db = new BookingsDB();
                db.DeleteBooking(bookingID );

                db.AddCancelledBooking(bookingID, cancellationReason, canceldate);
                ucBookings uc = new ucBookings();
                addUserControl(uc);


                if (result == DialogResult.OK)
                {
                    ucBookings uc0 = new ucBookings();
                    addUserControl(uc0);
                }
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnBack_Click_1(object sender, EventArgs e)
        {
            ucBookings uc = new ucBookings();
            addUserControl(uc);
        }
    }
}
