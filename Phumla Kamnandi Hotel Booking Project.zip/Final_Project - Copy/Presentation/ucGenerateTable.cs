﻿using PhumlaKamnandiMockup.Business;
using PhumlaKamnandiMockup.Data;
using PhumlaKamnandiMockup.UserControls;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using WinFormsListView = System.Windows.Forms.ListView;

namespace PhumlaKamnandiMockup.UserControls_and_Forms
{
    public partial class ucGenerateTable : UserControl
    {
        public ucGenerateTable()
        {
            InitializeComponent();
        }
        private void addUserControl02(UserControl userControl)
        {
            userControl.Dock = DockStyle.Fill;
            panelGenerate.Controls.Clear();
            panelGenerate.Controls.Add(userControl);
            userControl.BringToFront();
        }
        private void btnBack_Click(object sender, EventArgs e)
        {
            ucGenerateReport01 uc = new ucGenerateReport01();
            addUserControl02(uc);
        }

        private void panelGenerate_Paint(object sender, PaintEventArgs e)
        {

        }
        //generate occupancy report table 
        private void btnOccupancyReports_Click(object sender, EventArgs e)
        {
            // Ensure ListView is in Details mode to show columns properly
            GenTableListView.View = View.Details;

            // Clear the columns and re-add them for fresh data
            GenTableListView.Columns.Clear();
            GenTableListView.Columns.Add("Booking Date", 100);
            GenTableListView.Columns.Add("Total Guests", 100);

            // Get the start and end dates from the DateTimePicker controls
            DateTime startDate = dateTimestart.Value;
            DateTime endDate = dateTimeend.Value;

            // Create an instance of the OccupancyReport service
            var occupancyReportService = new OccupancyReport();

            // Generate the report data
            List<OccupancyData> reportData = occupancyReportService.GenerateOccupancyReport(startDate, endDate);

            // Check if any data was returned
            if (reportData.Count > 0)
            {
                // Display the report data in the ListView
                occupancyReportService.DisplayOccupancyReport(reportData, GenTableListView);
            }
            else
            {
                // Inform the user if no data was found
                MessageBox.Show("No occupancy data found for the selected dates.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }
        // Method to display cancellation report in a ListView

        public void DisplayCancellationReport(List<CancellationReport> reportData, System.Windows.Forms.ListView listview)
        {
            listview.Items.Clear(); // Clear any previous data

            foreach (var report in reportData)
            {
                ListViewItem item = new ListViewItem(report.BookingID);
                item.SubItems.Add(report.ReasonForCancellation);
                item.SubItems.Add(report.CancellationDate.ToString("yyyy-MM-dd"));

                listview.Items.Add(item); // Add each report data to ListView
            }
        }


        private void btnCancellationReports_Click(object sender, EventArgs e)
        {
            pictureBox1.Enabled = true;
            pictureBox1.Visible = true;

        }
            private void GenTableListView_SelectedIndexChanged(object sender, EventArgs e)
            {

            }
        }
    } 
