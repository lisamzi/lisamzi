﻿using PhumlaKamnandiMockup.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PhumlaKamnandiMockup.UserControls
{
    public partial class ucViewBooking01 : UserControl
    {
        public ucViewBooking01()
        {
            InitializeComponent();
        }

        private void addUserControl(UserControl userControl)
        {
            userControl.Dock = DockStyle.Fill;
            panelView.Controls.Clear();
            panelView.Controls.Add(userControl);
            userControl.BringToFront();
        }

        private void btnContinue_Click(object sender, EventArgs e)
        {
            //validate Booking ID input
            if (string.IsNullOrWhiteSpace(txtBookingID.Text))
            {
                MessageBox.Show("Please enter a Booking ID.", "Invalid Booking ID", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!System.Text.RegularExpressions.Regex.IsMatch(txtBookingID.Text, "^[a-zA-Z0-9]+$"))
            {
                MessageBox.Show("Booking ID must be alphanumeric.", "Invalid Booking ID", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Fetch booking from database
            BookingsDB db = new BookingsDB();
            var booking = db.GetBookingByID(txtBookingID.Text);

            if (booking == null)
            {
                //show error if booking not found
                MessageBox.Show("Booking not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //transition to the next user control with BookingID
            string BookingID = txtBookingID.Text;
            ucViewBooking02 ucView = new ucViewBooking02(BookingID);
            addUserControl(ucView);
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Controls.Remove(panelView);
            ucBookings uc = new ucBookings();
            this.Controls.Add(uc);
            uc.Dock = DockStyle.Fill;
            uc.BringToFront();
        }

        private void txtBookingID_TextChanged(object sender, EventArgs e) { }

        private void gpbUpdateBooking_Enter(object sender, EventArgs e) { }

        private void panelView_Paint(object sender, PaintEventArgs e) { }
    }
}


