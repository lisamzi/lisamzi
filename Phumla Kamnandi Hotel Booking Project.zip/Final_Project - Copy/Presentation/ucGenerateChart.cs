﻿using PhumlaKamnandiMockup.Business;
using PhumlaKamnandiMockup.UserControls;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PhumlaKamnandiMockup.UserControls_and_Forms
{
    public partial class ucGenerateChart : UserControl
    {
        public ucGenerateChart()
        {
            InitializeComponent();
        }
        private void addUserControl02(UserControl userControl)
        {
            userControl.Dock = DockStyle.Fill;
            panelGenerate.Controls.Clear();
            panelGenerate.Controls.Add(userControl);
            userControl.BringToFront();
        }
        private void btnBack_Click(object sender, EventArgs e)
        {
            ucGenerateReport01 uc = new ucGenerateReport01();
            addUserControl02(uc);
        }

        //generate occupancy reports chart
        private void btnOccupancyReports_Click(object sender, EventArgs e)
        {
            DateTime startDate = dateTimestart.Value;
            DateTime endDate = dateTimeend.Value;

            OccupancyReport occupancyReport = new OccupancyReport();
            var reportData = occupancyReport.GenerateOccupancyReport(startDate, endDate);

            occupancyReport.GenerateOccupancyChart(reportData, chart1);
        }
        //generate cancellation reports chart
        private void btnCancellationReports_Click(object sender, EventArgs e)
        {
            pictureBox1.Enabled = true;
            pictureBox1.Visible = true;
        }
        private void panelGenerate_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
