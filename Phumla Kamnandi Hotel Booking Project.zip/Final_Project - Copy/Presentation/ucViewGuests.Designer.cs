﻿namespace PhumlaKamnandiMockup.UserControls
{
    partial class ucViewGuests
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelViewGuests = new System.Windows.Forms.Panel();
            this.gpbCreateGuestProfile = new System.Windows.Forms.GroupBox();
            this.listViewGuest = new System.Windows.Forms.ListView();
            this.label5 = new System.Windows.Forms.Label();
            this.btnDone = new System.Windows.Forms.Button();
            this.panelViewGuests.SuspendLayout();
            this.gpbCreateGuestProfile.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelViewGuests
            // 
            this.panelViewGuests.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panelViewGuests.Controls.Add(this.gpbCreateGuestProfile);
            this.panelViewGuests.Location = new System.Drawing.Point(0, 0);
            this.panelViewGuests.Margin = new System.Windows.Forms.Padding(2);
            this.panelViewGuests.Name = "panelViewGuests";
            this.panelViewGuests.Size = new System.Drawing.Size(721, 529);
            this.panelViewGuests.TabIndex = 1;
            // 
            // gpbCreateGuestProfile
            // 
            this.gpbCreateGuestProfile.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.gpbCreateGuestProfile.Controls.Add(this.listViewGuest);
            this.gpbCreateGuestProfile.Controls.Add(this.label5);
            this.gpbCreateGuestProfile.Controls.Add(this.btnDone);
            this.gpbCreateGuestProfile.Location = new System.Drawing.Point(20, 17);
            this.gpbCreateGuestProfile.Name = "gpbCreateGuestProfile";
            this.gpbCreateGuestProfile.Size = new System.Drawing.Size(677, 488);
            this.gpbCreateGuestProfile.TabIndex = 4;
            this.gpbCreateGuestProfile.TabStop = false;
            this.gpbCreateGuestProfile.Enter += new System.EventHandler(this.gpbCreateGuestProfile_Enter);
            // 
            // listViewGuest
            // 
            this.listViewGuest.HideSelection = false;
            this.listViewGuest.Location = new System.Drawing.Point(24, 82);
            this.listViewGuest.Name = "listViewGuest";
            this.listViewGuest.Size = new System.Drawing.Size(627, 328);
            this.listViewGuest.TabIndex = 7;
            this.listViewGuest.UseCompatibleStateImageBehavior = false;
            this.listViewGuest.SelectedIndexChanged += new System.EventHandler(this.listViewGuest_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI Semibold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(19, 29);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(128, 30);
            this.label5.TabIndex = 4;
            this.label5.Text = "View Guests";
            // 
            // btnDone
            // 
            this.btnDone.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnDone.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray;
            this.btnDone.FlatAppearance.BorderSize = 0;
            this.btnDone.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btnDone.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnDone.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDone.Font = new System.Drawing.Font("Segoe UI Light", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDone.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnDone.Location = new System.Drawing.Point(24, 436);
            this.btnDone.Name = "btnDone";
            this.btnDone.Size = new System.Drawing.Size(108, 29);
            this.btnDone.TabIndex = 6;
            this.btnDone.Text = "Done";
            this.btnDone.UseVisualStyleBackColor = false;
            this.btnDone.Click += new System.EventHandler(this.btnDone_Click);
            // 
            // ucViewGuests
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panelViewGuests);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "ucViewGuests";
            this.Size = new System.Drawing.Size(721, 529);
            this.panelViewGuests.ResumeLayout(false);
            this.gpbCreateGuestProfile.ResumeLayout(false);
            this.gpbCreateGuestProfile.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelViewGuests;
        private System.Windows.Forms.GroupBox gpbCreateGuestProfile;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnDone;
        private System.Windows.Forms.ListView listViewGuest;
    }
}
