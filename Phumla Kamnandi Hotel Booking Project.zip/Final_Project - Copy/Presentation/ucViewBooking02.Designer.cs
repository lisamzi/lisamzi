﻿namespace PhumlaKamnandiMockup.UserControls
{
    partial class ucViewBooking02
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gpbViewBooking = new System.Windows.Forms.GroupBox();
            this.txtBookingStatus = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.btnDeleteBooking = new System.Windows.Forms.Button();
            this.btnUpdateBooking = new System.Windows.Forms.Button();
            this.txtTotalAmount = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtHotelName = new System.Windows.Forms.TextBox();
            this.txtHotelID = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtStayDuration = new System.Windows.Forms.TextBox();
            this.txtNoOfRooms = new System.Windows.Forms.TextBox();
            this.txtBookingID = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtDate = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.gpbGuestInformation = new System.Windows.Forms.GroupBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtCustName = new System.Windows.Forms.TextBox();
            this.txtCustID = new System.Windows.Forms.TextBox();
            this.txtNumberOfGuests = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.btnDone = new System.Windows.Forms.Button();
            this.panelViewBooking = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.gpbViewBooking.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.gpbGuestInformation.SuspendLayout();
            this.panelViewBooking.SuspendLayout();
            this.SuspendLayout();
            // 
            // gpbViewBooking
            // 
            this.gpbViewBooking.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.gpbViewBooking.Controls.Add(this.txtBookingStatus);
            this.gpbViewBooking.Controls.Add(this.txtTotalAmount);
            this.gpbViewBooking.Controls.Add(this.label15);
            this.gpbViewBooking.Controls.Add(this.label9);
            this.gpbViewBooking.Controls.Add(this.btnDeleteBooking);
            this.gpbViewBooking.Controls.Add(this.btnUpdateBooking);
            this.gpbViewBooking.Controls.Add(this.label19);
            this.gpbViewBooking.Controls.Add(this.groupBox2);
            this.gpbViewBooking.Controls.Add(this.txtBookingID);
            this.gpbViewBooking.Controls.Add(this.label11);
            this.gpbViewBooking.Controls.Add(this.label5);
            this.gpbViewBooking.Controls.Add(this.label4);
            this.gpbViewBooking.Controls.Add(this.txtDate);
            this.gpbViewBooking.Controls.Add(this.label1);
            this.gpbViewBooking.Controls.Add(this.gpbGuestInformation);
            this.gpbViewBooking.Controls.Add(this.btnDone);
            this.gpbViewBooking.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.gpbViewBooking.Location = new System.Drawing.Point(32, 39);
            this.gpbViewBooking.Margin = new System.Windows.Forms.Padding(2);
            this.gpbViewBooking.Name = "gpbViewBooking";
            this.gpbViewBooking.Padding = new System.Windows.Forms.Padding(2);
            this.gpbViewBooking.Size = new System.Drawing.Size(655, 458);
            this.gpbViewBooking.TabIndex = 0;
            this.gpbViewBooking.TabStop = false;
            this.gpbViewBooking.Enter += new System.EventHandler(this.gpbViewBooking_Enter);
            // 
            // txtBookingStatus
            // 
            this.txtBookingStatus.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtBookingStatus.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBookingStatus.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtBookingStatus.Location = new System.Drawing.Point(510, 23);
            this.txtBookingStatus.Margin = new System.Windows.Forms.Padding(2);
            this.txtBookingStatus.Name = "txtBookingStatus";
            this.txtBookingStatus.ReadOnly = true;
            this.txtBookingStatus.Size = new System.Drawing.Size(127, 20);
            this.txtBookingStatus.TabIndex = 91;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(415, 28);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(90, 15);
            this.label15.TabIndex = 90;
            this.label15.Text = "Booking Status:";
            // 
            // btnDeleteBooking
            // 
            this.btnDeleteBooking.BackColor = System.Drawing.Color.IndianRed;
            this.btnDeleteBooking.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray;
            this.btnDeleteBooking.FlatAppearance.BorderSize = 0;
            this.btnDeleteBooking.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btnDeleteBooking.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnDeleteBooking.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDeleteBooking.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteBooking.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnDeleteBooking.Location = new System.Drawing.Point(27, 399);
            this.btnDeleteBooking.Name = "btnDeleteBooking";
            this.btnDeleteBooking.Size = new System.Drawing.Size(191, 29);
            this.btnDeleteBooking.TabIndex = 89;
            this.btnDeleteBooking.Text = "Cancel Booking";
            this.btnDeleteBooking.UseVisualStyleBackColor = false;
            this.btnDeleteBooking.Click += new System.EventHandler(this.btnDeleteBooking_Click);
            // 
            // btnUpdateBooking
            // 
            this.btnUpdateBooking.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnUpdateBooking.Enabled = false;
            this.btnUpdateBooking.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray;
            this.btnUpdateBooking.FlatAppearance.BorderSize = 0;
            this.btnUpdateBooking.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btnUpdateBooking.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnUpdateBooking.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUpdateBooking.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateBooking.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnUpdateBooking.Location = new System.Drawing.Point(27, 354);
            this.btnUpdateBooking.Name = "btnUpdateBooking";
            this.btnUpdateBooking.Size = new System.Drawing.Size(191, 29);
            this.btnUpdateBooking.TabIndex = 88;
            this.btnUpdateBooking.Text = "Update Booking";
            this.btnUpdateBooking.UseVisualStyleBackColor = false;
            this.btnUpdateBooking.Click += new System.EventHandler(this.btnUpdateBooking_Click);
            // 
            // txtTotalAmount
            // 
            this.txtTotalAmount.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtTotalAmount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTotalAmount.ForeColor = System.Drawing.SystemColors.Info;
            this.txtTotalAmount.Location = new System.Drawing.Point(475, 319);
            this.txtTotalAmount.Margin = new System.Windows.Forms.Padding(2);
            this.txtTotalAmount.Name = "txtTotalAmount";
            this.txtTotalAmount.ReadOnly = true;
            this.txtTotalAmount.Size = new System.Drawing.Size(127, 20);
            this.txtTotalAmount.TabIndex = 70;
            this.txtTotalAmount.TextChanged += new System.EventHandler(this.txtTotalAmount_TextChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(332, 320);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(138, 15);
            this.label9.TabIndex = 71;
            this.label9.Text = "Total Amount (Incl. Tax):";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(18, 202);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(124, 17);
            this.label19.TabIndex = 84;
            this.label19.Text = "Hotel Information:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.txtHotelName);
            this.groupBox2.Controls.Add(this.txtHotelID);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.txtStayDuration);
            this.groupBox2.Controls.Add(this.txtNoOfRooms);
            this.groupBox2.Location = new System.Drawing.Point(20, 221);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox2.Size = new System.Drawing.Size(290, 114);
            this.groupBox2.TabIndex = 83;
            this.groupBox2.TabStop = false;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(4, 33);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(55, 15);
            this.label14.TabIndex = 79;
            this.label14.Text = "Hotel ID:";
            // 
            // txtHotelName
            // 
            this.txtHotelName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtHotelName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtHotelName.ForeColor = System.Drawing.SystemColors.Info;
            this.txtHotelName.Location = new System.Drawing.Point(88, 16);
            this.txtHotelName.Margin = new System.Windows.Forms.Padding(2);
            this.txtHotelName.Name = "txtHotelName";
            this.txtHotelName.ReadOnly = true;
            this.txtHotelName.Size = new System.Drawing.Size(196, 20);
            this.txtHotelName.TabIndex = 76;
            // 
            // txtHotelID
            // 
            this.txtHotelID.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtHotelID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtHotelID.ForeColor = System.Drawing.SystemColors.Info;
            this.txtHotelID.Location = new System.Drawing.Point(88, 35);
            this.txtHotelID.Margin = new System.Windows.Forms.Padding(2);
            this.txtHotelID.Name = "txtHotelID";
            this.txtHotelID.ReadOnly = true;
            this.txtHotelID.Size = new System.Drawing.Size(196, 20);
            this.txtHotelID.TabIndex = 75;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(4, 82);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(47, 15);
            this.label8.TabIndex = 79;
            this.label8.Text = "Rooms:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(4, 14);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(72, 15);
            this.label16.TabIndex = 43;
            this.label16.Text = "Hotel name:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(4, 59);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 15);
            this.label3.TabIndex = 42;
            this.label3.Text = "Stay duration:";
            // 
            // txtStayDuration
            // 
            this.txtStayDuration.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtStayDuration.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtStayDuration.ForeColor = System.Drawing.SystemColors.Info;
            this.txtStayDuration.Location = new System.Drawing.Point(88, 61);
            this.txtStayDuration.Margin = new System.Windows.Forms.Padding(2);
            this.txtStayDuration.Name = "txtStayDuration";
            this.txtStayDuration.ReadOnly = true;
            this.txtStayDuration.Size = new System.Drawing.Size(23, 20);
            this.txtStayDuration.TabIndex = 74;
            // 
            // txtNoOfRooms
            // 
            this.txtNoOfRooms.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtNoOfRooms.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtNoOfRooms.ForeColor = System.Drawing.SystemColors.Info;
            this.txtNoOfRooms.Location = new System.Drawing.Point(88, 83);
            this.txtNoOfRooms.Margin = new System.Windows.Forms.Padding(2);
            this.txtNoOfRooms.Name = "txtNoOfRooms";
            this.txtNoOfRooms.ReadOnly = true;
            this.txtNoOfRooms.Size = new System.Drawing.Size(23, 20);
            this.txtNoOfRooms.TabIndex = 73;
            // 
            // txtBookingID
            // 
            this.txtBookingID.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtBookingID.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtBookingID.Font = new System.Drawing.Font("Segoe UI Semilight", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBookingID.ForeColor = System.Drawing.SystemColors.ScrollBar;
            this.txtBookingID.Location = new System.Drawing.Point(162, 16);
            this.txtBookingID.Margin = new System.Windows.Forms.Padding(2);
            this.txtBookingID.Name = "txtBookingID";
            this.txtBookingID.ReadOnly = true;
            this.txtBookingID.Size = new System.Drawing.Size(192, 25);
            this.txtBookingID.TabIndex = 82;
            this.txtBookingID.Text = "*BookingID*";
            this.txtBookingID.TextChanged += new System.EventHandler(this.txtBookingID_TextChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI Semibold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(254, 234);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(0, 30);
            this.label11.TabIndex = 81;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI Semibold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(9, 14);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(144, 30);
            this.label5.TabIndex = 67;
            this.label5.Text = "View Booking";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(58, 47);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 15);
            this.label4.TabIndex = 66;
            this.label4.Text = "Booking date:";
            // 
            // txtDate
            // 
            this.txtDate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDate.ForeColor = System.Drawing.SystemColors.ScrollBar;
            this.txtDate.Location = new System.Drawing.Point(144, 46);
            this.txtDate.Margin = new System.Windows.Forms.Padding(2);
            this.txtDate.Name = "txtDate";
            this.txtDate.ReadOnly = true;
            this.txtDate.Size = new System.Drawing.Size(127, 20);
            this.txtDate.TabIndex = 69;
            this.txtDate.TextChanged += new System.EventHandler(this.txtDate_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(18, 85);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(125, 17);
            this.label1.TabIndex = 70;
            this.label1.Text = "Guest Information:";
            // 
            // gpbGuestInformation
            // 
            this.gpbGuestInformation.Controls.Add(this.label17);
            this.gpbGuestInformation.Controls.Add(this.label13);
            this.gpbGuestInformation.Controls.Add(this.txtCustName);
            this.gpbGuestInformation.Controls.Add(this.txtCustID);
            this.gpbGuestInformation.Controls.Add(this.txtNumberOfGuests);
            this.gpbGuestInformation.Controls.Add(this.label2);
            this.gpbGuestInformation.Controls.Add(this.label6);
            this.gpbGuestInformation.Controls.Add(this.label7);
            this.gpbGuestInformation.Controls.Add(this.label12);
            this.gpbGuestInformation.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gpbGuestInformation.Location = new System.Drawing.Point(20, 115);
            this.gpbGuestInformation.Margin = new System.Windows.Forms.Padding(2);
            this.gpbGuestInformation.Name = "gpbGuestInformation";
            this.gpbGuestInformation.Padding = new System.Windows.Forms.Padding(2);
            this.gpbGuestInformation.Size = new System.Drawing.Size(437, 73);
            this.gpbGuestInformation.TabIndex = 74;
            this.gpbGuestInformation.TabStop = false;
            this.gpbGuestInformation.Enter += new System.EventHandler(this.gpbGuestInformation_Enter);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(4, 34);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(56, 15);
            this.label13.TabIndex = 79;
            this.label13.Text = "Guest ID:";
            // 
            // txtCustName
            // 
            this.txtCustName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtCustName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCustName.ForeColor = System.Drawing.SystemColors.Info;
            this.txtCustName.Location = new System.Drawing.Point(79, 16);
            this.txtCustName.Margin = new System.Windows.Forms.Padding(2);
            this.txtCustName.Name = "txtCustName";
            this.txtCustName.ReadOnly = true;
            this.txtCustName.Size = new System.Drawing.Size(196, 23);
            this.txtCustName.TabIndex = 76;
            // 
            // txtCustID
            // 
            this.txtCustID.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtCustID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCustID.ForeColor = System.Drawing.SystemColors.Info;
            this.txtCustID.Location = new System.Drawing.Point(79, 36);
            this.txtCustID.Margin = new System.Windows.Forms.Padding(2);
            this.txtCustID.Name = "txtCustID";
            this.txtCustID.ReadOnly = true;
            this.txtCustID.Size = new System.Drawing.Size(196, 23);
            this.txtCustID.TabIndex = 75;
            // 
            // txtNumberOfGuests
            // 
            this.txtNumberOfGuests.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtNumberOfGuests.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtNumberOfGuests.ForeColor = System.Drawing.SystemColors.Info;
            this.txtNumberOfGuests.Location = new System.Drawing.Point(400, 16);
            this.txtNumberOfGuests.Margin = new System.Windows.Forms.Padding(2);
            this.txtNumberOfGuests.Name = "txtNumberOfGuests";
            this.txtNumberOfGuests.ReadOnly = true;
            this.txtNumberOfGuests.Size = new System.Drawing.Size(20, 23);
            this.txtNumberOfGuests.TabIndex = 71;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(284, 38);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 15);
            this.label2.TabIndex = 64;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(4, 14);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(73, 15);
            this.label6.TabIndex = 43;
            this.label6.Text = "Guest name:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(299, 16);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 15);
            this.label7.TabIndex = 44;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(290, 35);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(0, 15);
            this.label12.TabIndex = 56;
            // 
            // btnDone
            // 
            this.btnDone.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnDone.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray;
            this.btnDone.FlatAppearance.BorderSize = 0;
            this.btnDone.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btnDone.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnDone.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDone.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDone.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnDone.Location = new System.Drawing.Point(411, 354);
            this.btnDone.Name = "btnDone";
            this.btnDone.Size = new System.Drawing.Size(191, 29);
            this.btnDone.TabIndex = 68;
            this.btnDone.Text = "Done";
            this.btnDone.UseVisualStyleBackColor = false;
            this.btnDone.Click += new System.EventHandler(this.btnDone_Click);
            // 
            // panelViewBooking
            // 
            this.panelViewBooking.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panelViewBooking.Controls.Add(this.gpbViewBooking);
            this.panelViewBooking.Controls.Add(this.button1);
            this.panelViewBooking.Controls.Add(this.btnBack);
            this.panelViewBooking.Location = new System.Drawing.Point(0, 0);
            this.panelViewBooking.Margin = new System.Windows.Forms.Padding(2);
            this.panelViewBooking.Name = "panelViewBooking";
            this.panelViewBooking.Size = new System.Drawing.Size(721, 529);
            this.panelViewBooking.TabIndex = 1;
            this.panelViewBooking.Paint += new System.Windows.Forms.PaintEventHandler(this.panelViewBooking_Paint);
            // 
            // button1
            // 
            this.button1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button1.Location = new System.Drawing.Point(2, 2);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(42, 33);
            this.button1.TabIndex = 90;
            this.button1.Text = "←";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnBack
            // 
            this.btnBack.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnBack.FlatAppearance.BorderSize = 0;
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnBack.Location = new System.Drawing.Point(339, 248);
            this.btnBack.Margin = new System.Windows.Forms.Padding(2);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(42, 33);
            this.btnBack.TabIndex = 50;
            this.btnBack.Text = "←";
            this.btnBack.UseVisualStyleBackColor = true;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(290, 16);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(105, 15);
            this.label17.TabIndex = 92;
            this.label17.Text = "Number of guests:";
            // 
            // ucViewBooking02
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.Controls.Add(this.panelViewBooking);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "ucViewBooking02";
            this.Size = new System.Drawing.Size(721, 529);
            this.gpbViewBooking.ResumeLayout(false);
            this.gpbViewBooking.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.gpbGuestInformation.ResumeLayout(false);
            this.gpbGuestInformation.PerformLayout();
            this.panelViewBooking.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gpbViewBooking;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtDate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox gpbGuestInformation;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnDone;
        private System.Windows.Forms.TextBox txtTotalAmount;
        private System.Windows.Forms.TextBox txtStayDuration;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtCustName;
        private System.Windows.Forms.TextBox txtCustID;
        private System.Windows.Forms.TextBox txtNoOfRooms;
        private System.Windows.Forms.TextBox txtNumberOfGuests;
        private System.Windows.Forms.TextBox txtBookingID;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtHotelName;
        private System.Windows.Forms.TextBox txtHotelID;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btnDeleteBooking;
        private System.Windows.Forms.Button btnUpdateBooking;
        private System.Windows.Forms.Panel panelViewBooking;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.TextBox txtBookingStatus;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label17;
    }
}
