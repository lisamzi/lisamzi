﻿namespace PhumlaKamnandiMockup.UserControls
{
    partial class ucViewGuestDetails
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelGuestDetails = new System.Windows.Forms.Panel();
            this.btnBack = new System.Windows.Forms.Button();
            this.gpbCreateGuestProfile = new System.Windows.Forms.GroupBox();
            this.txtGuestID = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnViewGuest = new System.Windows.Forms.Button();
            this.panelGuestDetails.SuspendLayout();
            this.gpbCreateGuestProfile.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelGuestDetails
            // 
            this.panelGuestDetails.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panelGuestDetails.Controls.Add(this.btnBack);
            this.panelGuestDetails.Controls.Add(this.gpbCreateGuestProfile);
            this.panelGuestDetails.Location = new System.Drawing.Point(0, 0);
            this.panelGuestDetails.Margin = new System.Windows.Forms.Padding(2);
            this.panelGuestDetails.Name = "panelGuestDetails";
            this.panelGuestDetails.Size = new System.Drawing.Size(721, 529);
            this.panelGuestDetails.TabIndex = 0;
            // 
            // btnBack
            // 
            this.btnBack.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnBack.FlatAppearance.BorderSize = 0;
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnBack.Location = new System.Drawing.Point(135, 52);
            this.btnBack.Margin = new System.Windows.Forms.Padding(2);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(42, 33);
            this.btnBack.TabIndex = 50;
            this.btnBack.Text = "←";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // gpbCreateGuestProfile
            // 
            this.gpbCreateGuestProfile.Controls.Add(this.txtGuestID);
            this.gpbCreateGuestProfile.Controls.Add(this.label2);
            this.gpbCreateGuestProfile.Controls.Add(this.label4);
            this.gpbCreateGuestProfile.Controls.Add(this.label5);
            this.gpbCreateGuestProfile.Controls.Add(this.btnViewGuest);
            this.gpbCreateGuestProfile.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.gpbCreateGuestProfile.Location = new System.Drawing.Point(182, 52);
            this.gpbCreateGuestProfile.Name = "gpbCreateGuestProfile";
            this.gpbCreateGuestProfile.Size = new System.Drawing.Size(349, 422);
            this.gpbCreateGuestProfile.TabIndex = 4;
            this.gpbCreateGuestProfile.TabStop = false;
            this.gpbCreateGuestProfile.Enter += new System.EventHandler(this.gpbCreateGuestProfile_Enter);
            // 
            // txtGuestID
            // 
            this.txtGuestID.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGuestID.Location = new System.Drawing.Point(40, 132);
            this.txtGuestID.Name = "txtGuestID";
            this.txtGuestID.Size = new System.Drawing.Size(271, 23);
            this.txtGuestID.TabIndex = 10;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(39, 113);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 15);
            this.label2.TabIndex = 9;
            this.label2.Text = "Guest ID:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(37, 86);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(195, 15);
            this.label4.TabIndex = 3;
            this.label4.Text = "Please enter the following details:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI Semibold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(19, 29);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(185, 30);
            this.label5.TabIndex = 4;
            this.label5.Text = "View guest details";
            // 
            // btnViewGuest
            // 
            this.btnViewGuest.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnViewGuest.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray;
            this.btnViewGuest.FlatAppearance.BorderSize = 0;
            this.btnViewGuest.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btnViewGuest.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnViewGuest.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnViewGuest.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewGuest.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnViewGuest.Location = new System.Drawing.Point(40, 233);
            this.btnViewGuest.Name = "btnViewGuest";
            this.btnViewGuest.Size = new System.Drawing.Size(149, 29);
            this.btnViewGuest.TabIndex = 6;
            this.btnViewGuest.Text = "View Guest";
            this.btnViewGuest.UseVisualStyleBackColor = false;
            this.btnViewGuest.Click += new System.EventHandler(this.btnViewGuest_Click);
            // 
            // ucViewGuestDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.Controls.Add(this.panelGuestDetails);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "ucViewGuestDetails";
            this.Size = new System.Drawing.Size(721, 529);
            this.panelGuestDetails.ResumeLayout(false);
            this.gpbCreateGuestProfile.ResumeLayout(false);
            this.gpbCreateGuestProfile.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelGuestDetails;
        private System.Windows.Forms.GroupBox gpbCreateGuestProfile;
        private System.Windows.Forms.TextBox txtGuestID;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnViewGuest;
        private System.Windows.Forms.Button btnBack;
    }
}
