﻿using PhumlaKamnandiMockup.Business;
using PhumlaKamnandiMockup.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PhumlaKamnandiMockup.UserControls
{
    public partial class CreateBooking : UserControl
    {
        private ucCreateBooking01 previousControl;
        public int Adults;
        public int Children;
        public int Toddlers;
        public string HotelID;
        public DateTime CheckInDate;
        public DateTime CheckOutDate;
        public int NoOfGuests;
        public string Status;
        public string CustID;
        private CreateBooking ucCreateBooking02;
        public int TotalRooms;
        //private ucCreateBooking02 = this;

        public CreateBooking(ucCreateBooking01 prevControl, string CustID , string hotelID , DateTime checkindate, DateTime checkoutdate, string status,int noOfGuests, int totalRooms,int adults,int children,int toddlers)
        {
            InitializeComponent();
            this.CustID = CustID;  // Make sure this is assigned
            HotelID = hotelID;
            CheckInDate = checkindate;
            CheckOutDate = checkoutdate;
            Status = status;
            NoOfGuests = noOfGuests;  // Fixed: now it assigns correctly
            TotalRooms = totalRooms;
            Adults = adults;
            Children = children;
            Toddlers = toddlers;

            // Initialize ucCreateBooking02 with this current instance
            ucCreateBooking02 = this;




        }

        private void btnContinue_Click(object sender, EventArgs e)
        {

            CustID = txtGuestID.Text.Trim();

            // Validate custID
            if (!string.IsNullOrEmpty(CustID))
            {
                CustomerDB customerDB = new CustomerDB();

                // Check if customer exists
                if (customerDB.DoesCustomerIDExists(CustID))
                {
                    // Get customer name by custID
                    string customerName = customerDB.GetGuestNameByCustID(CustID);

                    if (!string.IsNullOrEmpty(customerName))
                    {
                        // Initialize ucCreateBooking03 with necessary parameters
                        ucCreateBooking03 ucBooking = new ucCreateBooking03(
                            this,           // Pass the current control (CreateBooking) as the previous control
                            HotelID,        // HotelID from current instance
                            NoOfGuests,     // NoOfGuests from current instance
                            CustID,         // CustID from current instance
                            CheckInDate,    // CheckInDate from current instance
                            CheckOutDate,    
                            TotalRooms,
                            Adults,
                            Children,
                            Toddlers
                     
                        );

                        // Replace the current control with ucCreateBooking03
                        addUserControl(ucBooking);
                    }
                    else
                    {
                        MessageBox.Show("Customer name could not be retrieved. Please check the Customer ID.",
                                        "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Customer ID does not exist. Please enter a valid Customer ID.",
                                    "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Please enter a valid Customer ID.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        
    }


        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Controls.Remove(panel1);
            ucCreateBooking01 uc = new ucCreateBooking01();
            this.Controls.Add(uc);
            uc.Dock = DockStyle.Fill;
            uc.BringToFront();
        
    }

        private void addUserControl(UserControl userControl)
        {
            userControl.Dock = DockStyle.Fill;
            panelCreateBooking2.Controls.Clear();
            panelCreateBooking2.Controls.Add(userControl);
            userControl.BringToFront();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            ucBookings ucBookings = new ucBookings();
            addUserControl(ucBookings);
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panelCreateBooking2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //open create guest profile
            ucCreateGuestProfile01 uc = new ucCreateGuestProfile01();
            addUserControl(uc);
        }
    }
}



