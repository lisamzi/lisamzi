﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PhumlaKamnandiMockup.UserControls
{
    public partial class ucCheckAvailibility02 : UserControl
    {
        private ucCheckAvailibility previousControl;
        public ucCheckAvailibility02(ucCheckAvailibility prevControl)
        {
            InitializeComponent();
            previousControl = prevControl;
        }

        private void btnBack_Click(object sender, EventArgs e)
        {

        }
        private void addUserControl(UserControl userControl)
        {
            userControl.Dock = DockStyle.Fill;
            panel1.Controls.Add(userControl);
            userControl.BringToFront();
        }
        private void btnCreateBooking_Click(object sender, EventArgs e)
        {
            ucCreateBooking01 ucCreateBooking01 = new ucCreateBooking01();
            addUserControl(ucCreateBooking01);
        }

        private void btnBack_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            previousControl.Show();
            previousControl.BringToFront();
        }

        private void gpbAvailibility_Enter(object sender, EventArgs e)
        {

        }
    }
}
