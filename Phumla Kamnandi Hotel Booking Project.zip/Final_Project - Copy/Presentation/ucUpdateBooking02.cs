﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PhumlaKamnandiMockup.UserControls
{
    public partial class ucUpdateBooking02 : UserControl
    {
        private ucUpdateBooking01 previousControl;
        public DateTime CheckIn;
        public DateTime CheckOut;
        public int adults;
        public int children;
        public int toddlers;
        public int Rooms;
        public string bookingID;


        public ucUpdateBooking02(ucUpdateBooking01 prevControl, string BookingID)
        {
            InitializeComponent();
            previousControl = prevControl;
            bookingID = BookingID;

            
            CheckIn = DateTime.Now; 
            CheckOut = DateTime.Now.AddDays(1); 

            numericUpDownAdult.Value = adults;
            numericUpDownChild.Value = children;
            numericUpDownToddler.Value = toddlers;

            
            dtCheckIn.Value = CheckIn;
            dtCheckout.Value = CheckOut;
            int rooms = (int)numericUpDownNoOfRooms.Value;
            Rooms = rooms;
            
        }


        private void addUserControl(UserControl userControl)
        {
            userControl.Dock = DockStyle.Fill;
            panel1.Controls.Add(userControl);
            userControl.BringToFront();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            DateTime checkin = dtCheckIn.Value;
            DateTime checkout = dtCheckout.Value;

            if (checkin > checkout)
            {
                MessageBox.Show("Check-in date cannot be in the past.", "Invalid Check-in Date", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (numericUpDownAdult.Value < 1)
            {
                MessageBox.Show("Please select at least one adult.", "Invalid Number of Adults", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Calculate rooms based on adults
            int numberOfAdults = (int)numericUpDownAdult.Value;
            int rooms = (numberOfAdults + 3) / 4;
            if (rooms < 1) rooms = 1;

            if (numberOfAdults > 8)
            {
                MessageBox.Show("You cannot select more than 8 adults in one booking.", "Invalid Number of Adults", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Pass the calculated values to the next control
            ucUpdateBooking03 uc = new ucUpdateBooking03(this, bookingID, dtCheckIn.Value, dtCheckout.Value, (int)numericUpDownAdult.Value, (int)numericUpDownChild.Value, (int)numericUpDownToddler.Value, (int)numericUpDownNoOfRooms.Value);
            addUserControl(uc);
        }


        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            previousControl.Show();
            previousControl.BringToFront();
        }

        private void addUserControl02(UserControl userControl)
        {
            userControl.Dock = DockStyle.Fill;
            panel1.Controls.Clear();
            panel1.Controls.Add(userControl);
            userControl.BringToFront();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            ucBookings uc = new ucBookings();
            addUserControl02(uc);
        }
     
        private void dateTimeBooking_ValueChanged(object sender, EventArgs e)
        {
            
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            
        }

        private void cmbSelectHotel_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void numericUpDownAdult_ValueChanged(object sender, EventArgs e)
        {
          
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
       
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
