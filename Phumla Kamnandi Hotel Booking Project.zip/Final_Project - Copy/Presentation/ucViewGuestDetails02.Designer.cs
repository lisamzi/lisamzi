﻿namespace PhumlaKamnandiMockup.UserControls
{
    partial class ucViewGuestDetails02
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnBack = new System.Windows.Forms.Button();
            this.gpbViewBooking = new System.Windows.Forms.GroupBox();
            this.lblGuestID = new System.Windows.Forms.Label();
            this.btnDeleteGuest = new System.Windows.Forms.Button();
            this.btnUpdateGuest = new System.Windows.Forms.Button();
            this.btnEditGuest = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.gpbGuestInformation = new System.Windows.Forms.GroupBox();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtContactNo = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtSurname = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.btnDone = new System.Windows.Forms.Button();
            this.gpbCreateGuestProfile = new System.Windows.Forms.GroupBox();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnViewGuest = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.dtDOB = new System.Windows.Forms.DateTimePicker();
            this.panel1.SuspendLayout();
            this.gpbViewBooking.SuspendLayout();
            this.gpbGuestInformation.SuspendLayout();
            this.gpbCreateGuestProfile.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.btnBack);
            this.panel1.Controls.Add(this.gpbViewBooking);
            this.panel1.Controls.Add(this.gpbCreateGuestProfile);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(721, 529);
            this.panel1.TabIndex = 0;
            // 
            // btnBack
            // 
            this.btnBack.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnBack.FlatAppearance.BorderSize = 0;
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnBack.Location = new System.Drawing.Point(0, 0);
            this.btnBack.Margin = new System.Windows.Forms.Padding(2);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(42, 33);
            this.btnBack.TabIndex = 50;
            this.btnBack.Text = "←";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // gpbViewBooking
            // 
            this.gpbViewBooking.Controls.Add(this.label3);
            this.gpbViewBooking.Controls.Add(this.dtDOB);
            this.gpbViewBooking.Controls.Add(this.lblGuestID);
            this.gpbViewBooking.Controls.Add(this.btnDeleteGuest);
            this.gpbViewBooking.Controls.Add(this.btnUpdateGuest);
            this.gpbViewBooking.Controls.Add(this.btnEditGuest);
            this.gpbViewBooking.Controls.Add(this.label11);
            this.gpbViewBooking.Controls.Add(this.label1);
            this.gpbViewBooking.Controls.Add(this.label7);
            this.gpbViewBooking.Controls.Add(this.gpbGuestInformation);
            this.gpbViewBooking.Controls.Add(this.btnDone);
            this.gpbViewBooking.Location = new System.Drawing.Point(28, 30);
            this.gpbViewBooking.Margin = new System.Windows.Forms.Padding(2);
            this.gpbViewBooking.Name = "gpbViewBooking";
            this.gpbViewBooking.Padding = new System.Windows.Forms.Padding(2);
            this.gpbViewBooking.Size = new System.Drawing.Size(666, 470);
            this.gpbViewBooking.TabIndex = 6;
            this.gpbViewBooking.TabStop = false;
            this.gpbViewBooking.Enter += new System.EventHandler(this.gpbViewBooking_Enter);
            // 
            // lblGuestID
            // 
            this.lblGuestID.AutoSize = true;
            this.lblGuestID.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGuestID.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblGuestID.Location = new System.Drawing.Point(156, 26);
            this.lblGuestID.Name = "lblGuestID";
            this.lblGuestID.Size = new System.Drawing.Size(50, 15);
            this.lblGuestID.TabIndex = 90;
            this.lblGuestID.Text = "GuestID";
            this.lblGuestID.Click += new System.EventHandler(this.lblGuestID_Click);
            // 
            // btnDeleteGuest
            // 
            this.btnDeleteGuest.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnDeleteGuest.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray;
            this.btnDeleteGuest.FlatAppearance.BorderSize = 0;
            this.btnDeleteGuest.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btnDeleteGuest.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnDeleteGuest.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDeleteGuest.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteGuest.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnDeleteGuest.Location = new System.Drawing.Point(24, 370);
            this.btnDeleteGuest.Name = "btnDeleteGuest";
            this.btnDeleteGuest.Size = new System.Drawing.Size(144, 29);
            this.btnDeleteGuest.TabIndex = 89;
            this.btnDeleteGuest.Text = "Delete Guest";
            this.btnDeleteGuest.UseVisualStyleBackColor = false;
            this.btnDeleteGuest.Click += new System.EventHandler(this.btnDeleteGuest_Click);
            // 
            // btnUpdateGuest
            // 
            this.btnUpdateGuest.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnUpdateGuest.Enabled = false;
            this.btnUpdateGuest.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray;
            this.btnUpdateGuest.FlatAppearance.BorderSize = 0;
            this.btnUpdateGuest.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btnUpdateGuest.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnUpdateGuest.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUpdateGuest.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateGuest.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnUpdateGuest.Location = new System.Drawing.Point(24, 334);
            this.btnUpdateGuest.Name = "btnUpdateGuest";
            this.btnUpdateGuest.Size = new System.Drawing.Size(144, 29);
            this.btnUpdateGuest.TabIndex = 88;
            this.btnUpdateGuest.Text = "Update Guest";
            this.btnUpdateGuest.UseVisualStyleBackColor = false;
            this.btnUpdateGuest.Click += new System.EventHandler(this.btnUpdateGuest_Click);
            // 
            // btnEditGuest
            // 
            this.btnEditGuest.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnEditGuest.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray;
            this.btnEditGuest.FlatAppearance.BorderSize = 0;
            this.btnEditGuest.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btnEditGuest.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnEditGuest.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEditGuest.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditGuest.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnEditGuest.Location = new System.Drawing.Point(24, 299);
            this.btnEditGuest.Name = "btnEditGuest";
            this.btnEditGuest.Size = new System.Drawing.Size(144, 29);
            this.btnEditGuest.TabIndex = 87;
            this.btnEditGuest.Text = "Edit Guest ";
            this.btnEditGuest.UseVisualStyleBackColor = false;
            this.btnEditGuest.Click += new System.EventHandler(this.btnEditGuest_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI Semibold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(250, 210);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(0, 30);
            this.label11.TabIndex = 81;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semibold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(9, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(119, 30);
            this.label1.TabIndex = 67;
            this.label1.Text = "View Guest";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label7.Location = new System.Drawing.Point(14, 52);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(107, 15);
            this.label7.TabIndex = 70;
            this.label7.Text = "Guest Information:";
            // 
            // gpbGuestInformation
            // 
            this.gpbGuestInformation.Controls.Add(this.txtAddress);
            this.gpbGuestInformation.Controls.Add(this.txtEmail);
            this.gpbGuestInformation.Controls.Add(this.txtContactNo);
            this.gpbGuestInformation.Controls.Add(this.label17);
            this.gpbGuestInformation.Controls.Add(this.label12);
            this.gpbGuestInformation.Controls.Add(this.label6);
            this.gpbGuestInformation.Controls.Add(this.label13);
            this.gpbGuestInformation.Controls.Add(this.txtName);
            this.gpbGuestInformation.Controls.Add(this.txtSurname);
            this.gpbGuestInformation.Controls.Add(this.label15);
            this.gpbGuestInformation.Location = new System.Drawing.Point(16, 70);
            this.gpbGuestInformation.Margin = new System.Windows.Forms.Padding(2);
            this.gpbGuestInformation.Name = "gpbGuestInformation";
            this.gpbGuestInformation.Padding = new System.Windows.Forms.Padding(2);
            this.gpbGuestInformation.Size = new System.Drawing.Size(306, 146);
            this.gpbGuestInformation.TabIndex = 74;
            this.gpbGuestInformation.TabStop = false;
            // 
            // txtAddress
            // 
            this.txtAddress.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtAddress.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAddress.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddress.ForeColor = System.Drawing.SystemColors.Info;
            this.txtAddress.Location = new System.Drawing.Point(97, 61);
            this.txtAddress.Margin = new System.Windows.Forms.Padding(2);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.ReadOnly = true;
            this.txtAddress.Size = new System.Drawing.Size(196, 23);
            this.txtAddress.TabIndex = 86;
            // 
            // txtEmail
            // 
            this.txtEmail.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtEmail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtEmail.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmail.ForeColor = System.Drawing.SystemColors.Info;
            this.txtEmail.Location = new System.Drawing.Point(97, 85);
            this.txtEmail.Margin = new System.Windows.Forms.Padding(2);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.ReadOnly = true;
            this.txtEmail.Size = new System.Drawing.Size(196, 23);
            this.txtEmail.TabIndex = 85;
            // 
            // txtContactNo
            // 
            this.txtContactNo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtContactNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtContactNo.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtContactNo.ForeColor = System.Drawing.SystemColors.Info;
            this.txtContactNo.Location = new System.Drawing.Point(120, 111);
            this.txtContactNo.Margin = new System.Windows.Forms.Padding(2);
            this.txtContactNo.Name = "txtContactNo";
            this.txtContactNo.ReadOnly = true;
            this.txtContactNo.Size = new System.Drawing.Size(173, 23);
            this.txtContactNo.TabIndex = 83;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label17.Location = new System.Drawing.Point(4, 61);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(52, 15);
            this.label17.TabIndex = 82;
            this.label17.Text = "Address:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label12.Location = new System.Drawing.Point(4, 109);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(96, 15);
            this.label12.TabIndex = 81;
            this.label12.Text = "Contact number:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label6.Location = new System.Drawing.Point(4, 85);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(39, 15);
            this.label6.TabIndex = 80;
            this.label6.Text = "Email:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label13.Location = new System.Drawing.Point(4, 36);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(64, 15);
            this.label13.TabIndex = 79;
            this.label13.Text = "Last name:";
            // 
            // txtName
            // 
            this.txtName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtName.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtName.ForeColor = System.Drawing.SystemColors.Info;
            this.txtName.Location = new System.Drawing.Point(97, 14);
            this.txtName.Margin = new System.Windows.Forms.Padding(2);
            this.txtName.Name = "txtName";
            this.txtName.ReadOnly = true;
            this.txtName.Size = new System.Drawing.Size(196, 23);
            this.txtName.TabIndex = 76;
            this.txtName.TextChanged += new System.EventHandler(this.textBox7_TextChanged);
            // 
            // txtSurname
            // 
            this.txtSurname.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtSurname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSurname.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSurname.ForeColor = System.Drawing.SystemColors.Info;
            this.txtSurname.Location = new System.Drawing.Point(97, 36);
            this.txtSurname.Margin = new System.Windows.Forms.Padding(2);
            this.txtSurname.Name = "txtSurname";
            this.txtSurname.ReadOnly = true;
            this.txtSurname.Size = new System.Drawing.Size(196, 23);
            this.txtSurname.TabIndex = 75;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label15.Location = new System.Drawing.Point(4, 14);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(65, 15);
            this.label15.TabIndex = 43;
            this.label15.Text = "First name:";
            // 
            // btnDone
            // 
            this.btnDone.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnDone.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray;
            this.btnDone.FlatAppearance.BorderSize = 0;
            this.btnDone.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btnDone.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnDone.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDone.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDone.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnDone.Location = new System.Drawing.Point(24, 405);
            this.btnDone.Name = "btnDone";
            this.btnDone.Size = new System.Drawing.Size(144, 29);
            this.btnDone.TabIndex = 68;
            this.btnDone.Text = "Done";
            this.btnDone.UseVisualStyleBackColor = false;
            this.btnDone.Click += new System.EventHandler(this.btnDone_Click);
            // 
            // gpbCreateGuestProfile
            // 
            this.gpbCreateGuestProfile.Controls.Add(this.txtFirstName);
            this.gpbCreateGuestProfile.Controls.Add(this.label2);
            this.gpbCreateGuestProfile.Controls.Add(this.label4);
            this.gpbCreateGuestProfile.Controls.Add(this.label5);
            this.gpbCreateGuestProfile.Controls.Add(this.btnViewGuest);
            this.gpbCreateGuestProfile.Location = new System.Drawing.Point(262, 217);
            this.gpbCreateGuestProfile.Name = "gpbCreateGuestProfile";
            this.gpbCreateGuestProfile.Size = new System.Drawing.Size(0, 0);
            this.gpbCreateGuestProfile.TabIndex = 5;
            this.gpbCreateGuestProfile.TabStop = false;
            // 
            // txtFirstName
            // 
            this.txtFirstName.Location = new System.Drawing.Point(40, 142);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(271, 20);
            this.txtFirstName.TabIndex = 10;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI Light", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(39, 124);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 15);
            this.label2.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(37, 97);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 15);
            this.label4.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI Semibold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(19, 40);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 30);
            this.label5.TabIndex = 4;
            // 
            // btnViewGuest
            // 
            this.btnViewGuest.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnViewGuest.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray;
            this.btnViewGuest.FlatAppearance.BorderSize = 0;
            this.btnViewGuest.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btnViewGuest.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnViewGuest.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnViewGuest.Font = new System.Drawing.Font("Segoe UI Light", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewGuest.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnViewGuest.Location = new System.Drawing.Point(98, 277);
            this.btnViewGuest.Name = "btnViewGuest";
            this.btnViewGuest.Size = new System.Drawing.Size(108, 29);
            this.btnViewGuest.TabIndex = 6;
            this.btnViewGuest.UseVisualStyleBackColor = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(39, 232);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 15);
            this.label3.TabIndex = 92;
            this.label3.Text = "Date of Birth:";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // dtDOB
            // 
            this.dtDOB.Location = new System.Drawing.Point(122, 227);
            this.dtDOB.Name = "dtDOB";
            this.dtDOB.Size = new System.Drawing.Size(200, 20);
            this.dtDOB.TabIndex = 91;
            // 
            // ucViewGuestDetails02
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "ucViewGuestDetails02";
            this.Size = new System.Drawing.Size(721, 529);
            this.panel1.ResumeLayout(false);
            this.gpbViewBooking.ResumeLayout(false);
            this.gpbViewBooking.PerformLayout();
            this.gpbGuestInformation.ResumeLayout(false);
            this.gpbGuestInformation.PerformLayout();
            this.gpbCreateGuestProfile.ResumeLayout(false);
            this.gpbCreateGuestProfile.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox gpbCreateGuestProfile;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnViewGuest;
        private System.Windows.Forms.GroupBox gpbViewBooking;
        private System.Windows.Forms.Button btnDeleteGuest;
        private System.Windows.Forms.Button btnUpdateGuest;
        private System.Windows.Forms.Button btnEditGuest;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox gpbGuestInformation;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtContactNo;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtSurname;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button btnDone;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Label lblGuestID;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker dtDOB;
    }
}
