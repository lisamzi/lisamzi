﻿using PhumlaKamnandiMockup.Business;
using PhumlaKamnandiMockup.Business.PhumlaKamnandiMockup.Business;
using PhumlaKamnandiMockup.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PhumlaKamnandiMockup.UserControls
{
    public partial class ucCreateBooking03 : UserControl
    {
        private CreateBooking previousControl;
        public string CustID;
        public DateTime CheckIn;
        public DateTime CheckOut;
        public int TotalRooms;
        public int Duration;
        public decimal Amount;
        public int Adults;
        public int Children;
        public int Toddlers;
        public int NoOfGuests;
        public string HotelID;
        public decimal Deposit;




        public ucCreateBooking03(CreateBooking prevControl, string hotelID, int noOfGuests, string custID, DateTime checkInDate, DateTime checkOutDate, int rooms, int adults, int children, int toddlers)
        {
            InitializeComponent();
            previousControl = prevControl;

            CustID = custID;
            CheckIn = checkInDate;
            CheckOut = checkOutDate;
            TotalRooms = rooms;
            NoOfGuests = noOfGuests;
            Adults = adults;
            Children = children;
            Toddlers = toddlers;

            // Assuming Amount is initialized somewhere before this point
            txtDeposit.Text = Deposit.ToString("C", new CultureInfo("en-ZA")); // This line should be after Deposit is set

            CustomerDB custDB = new CustomerDB();
            string name = custDB.GetGuestNameByCustID(custID);
            txtName.Enabled = false;
            txtName.Text = name;

            int stayDuration = (CheckOut - CheckIn).Days;
            txtStayDuration.Enabled = false;
            txtStayDuration.Text = Convert.ToString(stayDuration);
            txtNoOfGuests.Enabled = false;
            txtNoOfGuests.Text = Convert.ToString(noOfGuests);
            txtNoOfRooms.Enabled = false;
            txtNoOfRooms.Text = Convert.ToString(rooms);

            HotelID = hotelID;

            txtSubtotal.Enabled = false;

            Payment payment = new Payment();
            string season = payment.DetermineSeason(checkInDate);
            double subtotal = payment.GetPrice(season, noOfGuests, toddlers, children, adults, stayDuration);
            double Tax = subtotal * 15 / 100;
            double TotalAmount = subtotal + Tax;

            decimal Total = Convert.ToDecimal(TotalAmount);
            Amount = Total; // Assuming you want to store the total amount
            txtSubtotal.Text = subtotal.ToString("C", new CultureInfo("en-ZA"));
            txtTax.Text = Tax.ToString("C", new CultureInfo("en-ZA"));
            txtTotalAmountTax.Text = TotalAmount.ToString("C", new CultureInfo("en-ZA"));

            // Call the Calc method here to set Deposit correctly
            Deposit = Calc(Total);

            // Set the Deposit text after it is calculated
            txtDeposit.Text = Deposit.ToString("C", new CultureInfo("en-ZA"));

            txtDate.Text = $"{checkInDate:dd/MM/yyyy} - {checkOutDate:dd/MM/yyyy}";
        }


        private decimal Calc(decimal subtotal)
        {
            const decimal taxRate = 0.15m; //15%
            const decimal depositRate = 0.10m; //10%

            decimal taxAmount = subtotal * taxRate;
            decimal totalAmount = subtotal + taxAmount;
            decimal depositAmount = totalAmount * depositRate;

            
            Deposit = depositAmount;
            return Deposit; 
        }


        private void btnContinue_Click(object sender, EventArgs e)
        {
            // Create an instance of ucCreateBooking04 with the necessary parameters
            ucCreateBooking04 ucBooking04 = new ucCreateBooking04(
                this,           // Pass the current control (CreateBooking) as the previous control
                HotelID,       // HotelID from current instance
                CustID,        // CustID from current instance
                CheckIn,       // CheckInDate from current instance
                CheckOut,      // CheckOutDate from current instance
                NoOfGuests,    // NoOfGuests from current instance
                TotalRooms,  // TotalRooms from current instance
                Adults,        // Adults count (make sure this variable is defined)
                Children,      // Children count (make sure this variable is defined)
                Toddlers, Amount      // Toddlers count (make sure this variable is defined)
            );

            // Replace the current control with ucCreateBooking04
            addUserControl(ucBooking04);
        }

        private void addUserControl(UserControl userControl)
        {
            userControl.Dock = DockStyle.Fill;
            panel1BookingInvoice.Controls.Clear();
            panel1BookingInvoice.Controls.Add(userControl);
            userControl.BringToFront();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            ucCreateBooking01 ucBooking01 = new ucCreateBooking01();
            addUserControl(ucBooking01);
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            ucBookings ucBookings = new ucBookings();
            addUserControl(ucBookings);
        }

        private void txtTotalAmountTax_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void txtTax_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void txtSubtotal_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void txtName_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void panel1BookingInvoice_Paint(object sender, PaintEventArgs e)
        {

        }

        private void txtDeposit_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
            txtDeposit.Text = Deposit.ToString();
        }
    }
}
