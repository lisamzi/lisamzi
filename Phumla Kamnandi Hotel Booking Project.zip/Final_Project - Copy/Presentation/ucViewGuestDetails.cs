﻿using PhumlaKamnandiMockup.Business;
using PhumlaKamnandiMockup.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PhumlaKamnandiMockup.UserControls
{
    public partial class ucViewGuestDetails : UserControl
    {
        public string GuestID { get; set; }

        public ucViewGuestDetails()
        {
            InitializeComponent();
        }

        private void addUserControl(UserControl userControl)
        {
            userControl.Dock = DockStyle.Fill;
            panelGuestDetails.Controls.Clear();
            panelGuestDetails.Controls.Add(userControl);
            userControl.BringToFront();
        }

        private void btnViewGuest_Click(object sender, EventArgs e)
        {
            
            if (string.IsNullOrWhiteSpace(txtGuestID.Text))
            {
                MessageBox.Show("Please enter a valid Guest ID.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

           
            CustomerDB customerDB = new CustomerDB();
            string id = txtGuestID.Text;

            try
            {
                
                Customer customer = customerDB.GetCustomerById(id);

                if (customer != null)
                {
                    
                    ucViewGuestDetails02 ucViewGuest02 = new ucViewGuestDetails02(customer);
                    addUserControl(ucViewGuest02);
                }
                else
                {
                    MessageBox.Show("Guest not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while retrieving guest details: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Controls.Remove(panelGuestDetails);
            ucGuests uc = new ucGuests();
            this.Controls.Add(uc);
            uc.Dock = DockStyle.Fill;
            uc.BringToFront();
        }

        private void gpbCreateGuestProfile_Enter(object sender, EventArgs e)
        {

        }
    }
}


