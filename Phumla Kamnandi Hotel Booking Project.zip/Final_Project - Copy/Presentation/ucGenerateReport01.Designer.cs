﻿namespace PhumlaKamnandiMockup.UserControls
{
    partial class ucGenerateReport01
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelGenerate = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnGenerateTable = new System.Windows.Forms.Button();
            this.btnGenerateChart = new System.Windows.Forms.Button();
            this.panelGenerate.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelGenerate
            // 
            this.panelGenerate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panelGenerate.Controls.Add(this.groupBox1);
            this.panelGenerate.Location = new System.Drawing.Point(0, 0);
            this.panelGenerate.Name = "panelGenerate";
            this.panelGenerate.Size = new System.Drawing.Size(721, 529);
            this.panelGenerate.TabIndex = 0;
            this.panelGenerate.Paint += new System.Windows.Forms.PaintEventHandler(this.panelGenerate_Paint);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnGenerateTable);
            this.groupBox1.Controls.Add(this.btnGenerateChart);
            this.groupBox1.Location = new System.Drawing.Point(19, 20);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(684, 290);
            this.groupBox1.TabIndex = 72;
            this.groupBox1.TabStop = false;
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // btnGenerateTable
            // 
            this.btnGenerateTable.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnGenerateTable.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnGenerateTable.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnGenerateTable.FlatAppearance.MouseOverBackColor = System.Drawing.Color.CornflowerBlue;
            this.btnGenerateTable.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGenerateTable.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGenerateTable.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnGenerateTable.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnGenerateTable.Location = new System.Drawing.Point(20, 29);
            this.btnGenerateTable.Name = "btnGenerateTable";
            this.btnGenerateTable.Size = new System.Drawing.Size(168, 43);
            this.btnGenerateTable.TabIndex = 6;
            this.btnGenerateTable.Text = "Generate Table";
            this.btnGenerateTable.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGenerateTable.UseVisualStyleBackColor = false;
            this.btnGenerateTable.Click += new System.EventHandler(this.btnGenerateTable_Click);
            // 
            // btnGenerateChart
            // 
            this.btnGenerateChart.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnGenerateChart.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnGenerateChart.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnGenerateChart.FlatAppearance.MouseOverBackColor = System.Drawing.Color.CornflowerBlue;
            this.btnGenerateChart.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGenerateChart.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGenerateChart.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnGenerateChart.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnGenerateChart.Location = new System.Drawing.Point(20, 84);
            this.btnGenerateChart.Name = "btnGenerateChart";
            this.btnGenerateChart.Size = new System.Drawing.Size(168, 40);
            this.btnGenerateChart.TabIndex = 7;
            this.btnGenerateChart.Text = "Generate Chart";
            this.btnGenerateChart.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGenerateChart.UseVisualStyleBackColor = false;
            this.btnGenerateChart.Click += new System.EventHandler(this.btnGenerateChart_Click);
            // 
            // ucGenerateReport01
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panelGenerate);
            this.Name = "ucGenerateReport01";
            this.Size = new System.Drawing.Size(721, 529);
            this.panelGenerate.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panelGenerate;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnGenerateTable;
        private System.Windows.Forms.Button btnGenerateChart;
    }
}
