﻿using PhumlaKamnandiMockup.Business;
using PhumlaKamnandiMockup.Business.PhumlaKamnandiMockup.Business;
using PhumlaKamnandiMockup.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PhumlaKamnandiMockup.UserControls
{
    public partial class ucUpdateBooking03 : UserControl
    {
        public string BookingID;
        public DateTime checkIn;
        public DateTime checkOut;
        public int Adults;
        public int Children;
        public int Toddlers;
        public int Rooms;
        private ucUpdateBooking02 previousUC;
        public int noOfGuests;
        public decimal total;
        public ucUpdateBooking03(ucUpdateBooking02 prevUC, string bookingID, DateTime checkIn, DateTime checkOut, int adults, int children, int toddlers, int rooms)
        {
            InitializeComponent();
            previousUC = prevUC; 
            BookingID = bookingID; 
            this.checkIn = checkIn; 
            this.checkOut = checkOut; 
            this.Adults = adults; 
            this.Children = children; 
            this.Toddlers = toddlers; 
            this.Rooms = rooms; 

           
            txtCheckIn.Text = checkIn.ToString("d"); 
            txtCheckOut.Text = checkOut.ToString("d");
            txtAdults.Text = this.Adults.ToString(); 
            txtChildren.Text = this.Children.ToString();
            txtToddlers.Text = this.Toddlers.ToString();

     
            noOfGuests = this.Adults + this.Children + this.Toddlers;
            txtGuests.Text = noOfGuests.ToString();

           
            Payment p = new Payment();
            string season = p.DetermineSeason(checkIn);
            int duration = CalculateDurationOfStay();
            double price = p.GetPrice(season, noOfGuests, Toddlers, Children, Adults, duration);
            total = (decimal)price; 

           
            txtTotal.Text = total.ToString("C", new CultureInfo("en-ZA")); 
        }


        private int CalculateDurationOfStay()
        {
            return (checkOut - checkIn).Days; 
        }
        private void addUserControl(UserControl userControl)
        {
            userControl.Dock = DockStyle.Fill;
            panel1.Controls.Add(userControl);
            userControl.BringToFront();
        }
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            
            Booking updatedBooking = new Booking
            {
                BookingID = BookingID, 
                NoOfGuests = noOfGuests,
                CheckInDate = checkIn,
                CheckOutDate = checkOut,
                NoOfRooms = Rooms,
                TotalAmount = total 
            };

            BookingsDB bookingsDb = new BookingsDB(); 
            try
            {
                
                bool isUpdated = bookingsDb.UpdateBooking(BookingID, noOfGuests, checkIn, checkOut, total, Rooms);

                if (isUpdated)
                {
                    MessageBox.Show("Booking Updated Successfully", "Booking has successfully been updated.", MessageBoxButtons.OK);
                    ucBookings uc = new ucBookings();
                    addUserControl(uc);
                }
                else
                {
                    MessageBox.Show("Update Unsuccessful", "Booking update failed.", MessageBoxButtons.OK);
                    ucBookings uc = new ucBookings();
                    addUserControl(uc);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Update Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            previousUC.Show();
            previousUC.BringToFront();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
        private void addUserControl02(UserControl userControl)
        {
            userControl.Dock = DockStyle.Fill;
            panel1.Controls.Clear();
            panel1.Controls.Add(userControl);
            userControl.BringToFront();
        }
        private void btnCancel_Click(object sender, EventArgs e)
        {
            ucBookings uc = new ucBookings();
            addUserControl02(uc);
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void txtCheckIn_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
