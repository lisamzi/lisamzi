﻿using PhumlaKamnandiMockup.Data;
using PhumlaKamnandiMockup.Presentation;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PhumlaKamnandiMockup.UserControls
{
    public partial class ucViewBooking02 : UserControl
    {
        private string bookingID;

        public ucViewBooking02(string BookingID)
        {
            InitializeComponent();
            bookingID = BookingID;
            LoadBookingDetails(); // Load booking details when the control is initialized
        }

        private void LoadBookingDetails()
        {
            BookingsDB bookingsDB = new BookingsDB();
            // Use the bookingID to fetch and populate booking details
            var bookingDetails = bookingsDB.GetBookingByID(bookingID);

            if (bookingDetails != null)
            {
                // Calculate stay duration
                TimeSpan stayDuration = bookingDetails.CheckOutDate - bookingDetails.CheckInDate;

                // Populate the form fields with booking details
                CustomerDB customerDB = new CustomerDB();
                string guestName = customerDB.GetGuestNameByCustID(bookingDetails.CustID);

                txtCustName.Text = guestName;  // Update customer name
                txtCustID.Text = bookingDetails.CustID;
                txtDate.Text = $"{bookingDetails.CheckInDate:dd/MM/yyyy} - {bookingDetails.CheckOutDate:dd/MM/yyyy}";
                txtBookingStatus.Text = bookingDetails.Status;
                txtHotelName.Text = "Phumla Kamnandi";
                txtHotelID.Text = bookingDetails.HotelID;
                txtStayDuration.Text = stayDuration.ToString();
                txtNoOfRooms.Text = bookingDetails.NoOfRooms.ToString();
                txtTotalAmount.Text = bookingDetails.TotalAmount.ToString();
                txtNumberOfGuests.Text = bookingDetails.NoOfGuests.ToString();
               
                txtBookingID.Text = bookingDetails.BookingID;
                //txtTotalAmount.Text = bookingDetails.Total.ToString(); // Uncomment if you have total amount
            }
            else
            {
                //show an error if no booking is found
                MessageBox.Show("Booking not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDeleteBooking_Click(object sender, EventArgs e)
        {
           ucDeleteBooking01 uc = new ucDeleteBooking01();
           addUserControl(uc);
        }
        private void addUserControl(UserControl userControl)
        {
            userControl.Dock = DockStyle.Fill;
            panelViewBooking.Controls.Clear();
            panelViewBooking.Controls.Add(userControl);
            userControl.BringToFront();
        }
        private void btnUpdateBooking_Click(object sender, EventArgs e)
        {
            ucUpdateBooking01 uc = new ucUpdateBooking01();
            addUserControl(uc); 
        }

        private void btnDone_Click(object sender, EventArgs e)
        {
            this.Controls.Remove(panelViewBooking);
            ucHome home = new ucHome();
            this.Controls.Add(home);
            home.Dock = DockStyle.Fill;
            home.BringToFront();
        }

        private void btnChangePaymentStatus_Click(object sender, EventArgs e)
        {
            
            btnUpdateBooking.Enabled = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Controls.Remove(panelViewBooking);
            ucViewBooking01 uc = new ucViewBooking01();
            this.Controls.Add(uc);
            uc.Dock = DockStyle.Fill;
            uc.BringToFront();
        }

        private void gpbViewBooking_Enter(object sender, EventArgs e) { }

        private void panelViewBooking_Paint(object sender, PaintEventArgs e) { }

        private void txtDate_TextChanged(object sender, EventArgs e) { }

        private void txtBookingID_TextChanged(object sender, EventArgs e) { }

        private void txtTotalAmount_TextChanged(object sender, EventArgs e) { }

        private void gpbGuestInformation_Enter(object sender, EventArgs e)
        {

        }
    }
}

