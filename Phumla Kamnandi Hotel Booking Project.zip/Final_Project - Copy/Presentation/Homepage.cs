﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PhumlaKamnandiMockup.UserControls
{
    public partial class SecondFormcs : Form
    {
        public SecondFormcs()
        {
            InitializeComponent();
        }
        //method to change buttons to the same colour
        private void ChangeAllButtonColors()
        {
            Color newColor = Color.FromArgb(64, 64, 64) ; 

            foreach (Control control in panelControls.Controls)
            {
                if (control is Button)
                {
                    control.BackColor = newColor;
                }
            }
        }

        private void addUserControl(UserControl userControl)
        {
            userControl.Dock = DockStyle.Fill;
            panelHome.Controls.Clear();
            panelHome.Controls.Add(userControl);
            userControl.BringToFront();
        }
        private void btnHomepage_Click(object sender, EventArgs e)
        {
            ChangeAllButtonColors();
            btnHomepage.BackColor = Color.RoyalBlue;
            ucHome ucHome = new ucHome();
            addUserControl(ucHome);
        }

        private void btnBookings_Click(object sender, EventArgs e)
        {
            ChangeAllButtonColors();
            btnBookings.BackColor = Color.RoyalBlue;
            ucBookings ucBookings = new ucBookings();
            addUserControl(ucBookings);
        }

        private void btnGuests_Click(object sender, EventArgs e)
        {
            ChangeAllButtonColors();
            btnGuests.BackColor = Color.RoyalBlue;
            ucGuests ucGuests  = new ucGuests();
            addUserControl(ucGuests);
        }

       

      
        private void btnReports_Click(object sender, EventArgs e)
        {
            ChangeAllButtonColors();
            btnReports.BackColor = Color.RoyalBlue;
            ucGenerateReport01 ucReports = new ucGenerateReport01();
            addUserControl (ucReports);
        }

        private void SecondFormcs_Load(object sender, EventArgs e)
        {
            btnHomepage.BackColor = Color.RoyalBlue;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void panelControls_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
