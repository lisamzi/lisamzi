﻿namespace PhumlaKamnandiMockup.UserControls
{
    partial class ucCreateBooking01
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnBack = new System.Windows.Forms.Button();
            this.panel1CreateBooking = new System.Windows.Forms.Panel();
            this.GetHotelName = new System.Windows.Forms.ComboBox();
            this.totalRooms = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.dateTimeCheckOut = new System.Windows.Forms.DateTimePicker();
            this.btnContinue = new System.Windows.Forms.Button();
            this.numOfAdults = new System.Windows.Forms.NumericUpDown();
            this.NoOfChildren = new System.Windows.Forms.NumericUpDown();
            this.NoOfToddlers = new System.Windows.Forms.NumericUpDown();
            this.label8 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dateTimeCheckIN = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel1CreateBooking.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.totalRooms)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numOfAdults)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NoOfChildren)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NoOfToddlers)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.btnBack);
            this.panel1.Controls.Add(this.panel1CreateBooking);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(721, 529);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // btnBack
            // 
            this.btnBack.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnBack.FlatAppearance.BorderSize = 0;
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnBack.Location = new System.Drawing.Point(122, 46);
            this.btnBack.Margin = new System.Windows.Forms.Padding(2);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(42, 33);
            this.btnBack.TabIndex = 49;
            this.btnBack.Text = "←";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // panel1CreateBooking
            // 
            this.panel1CreateBooking.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel1CreateBooking.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1CreateBooking.Controls.Add(this.GetHotelName);
            this.panel1CreateBooking.Controls.Add(this.totalRooms);
            this.panel1CreateBooking.Controls.Add(this.label1);
            this.panel1CreateBooking.Controls.Add(this.label9);
            this.panel1CreateBooking.Controls.Add(this.dateTimeCheckOut);
            this.panel1CreateBooking.Controls.Add(this.btnContinue);
            this.panel1CreateBooking.Controls.Add(this.numOfAdults);
            this.panel1CreateBooking.Controls.Add(this.NoOfChildren);
            this.panel1CreateBooking.Controls.Add(this.NoOfToddlers);
            this.panel1CreateBooking.Controls.Add(this.label8);
            this.panel1CreateBooking.Controls.Add(this.label5);
            this.panel1CreateBooking.Controls.Add(this.label7);
            this.panel1CreateBooking.Controls.Add(this.label4);
            this.panel1CreateBooking.Controls.Add(this.label6);
            this.panel1CreateBooking.Controls.Add(this.label2);
            this.panel1CreateBooking.Controls.Add(this.dateTimeCheckIN);
            this.panel1CreateBooking.Controls.Add(this.label3);
            this.panel1CreateBooking.Location = new System.Drawing.Point(168, 46);
            this.panel1CreateBooking.Margin = new System.Windows.Forms.Padding(2);
            this.panel1CreateBooking.Name = "panel1CreateBooking";
            this.panel1CreateBooking.Size = new System.Drawing.Size(356, 429);
            this.panel1CreateBooking.TabIndex = 47;
            // 
            // GetHotelName
            // 
            this.GetHotelName.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GetHotelName.FormattingEnabled = true;
            this.GetHotelName.Items.AddRange(new object[] {
            "H001"});
            this.GetHotelName.Location = new System.Drawing.Point(36, 286);
            this.GetHotelName.Name = "GetHotelName";
            this.GetHotelName.Size = new System.Drawing.Size(121, 24);
            this.GetHotelName.TabIndex = 51;
            this.GetHotelName.Text = "Choose Hotel";
            this.GetHotelName.SelectedIndexChanged += new System.EventHandler(this.GetHotelName_SelectedIndexChanged);
            // 
            // totalRooms
            // 
            this.totalRooms.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.totalRooms.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.totalRooms.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.totalRooms.Location = new System.Drawing.Point(178, 320);
            this.totalRooms.Name = "totalRooms";
            this.totalRooms.Size = new System.Drawing.Size(34, 16);
            this.totalRooms.TabIndex = 50;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(37, 321);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 15);
            this.label1.TabIndex = 49;
            this.label1.Text = "Total rooms:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label9.Location = new System.Drawing.Point(175, 95);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(63, 15);
            this.label9.TabIndex = 48;
            this.label9.Text = "Check out:";
            // 
            // dateTimeCheckOut
            // 
            this.dateTimeCheckOut.CalendarMonthBackground = System.Drawing.SystemColors.ButtonHighlight;
            this.dateTimeCheckOut.Font = new System.Drawing.Font("Segoe UI Light", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimeCheckOut.Location = new System.Drawing.Point(178, 120);
            this.dateTimeCheckOut.Name = "dateTimeCheckOut";
            this.dateTimeCheckOut.Size = new System.Drawing.Size(139, 22);
            this.dateTimeCheckOut.TabIndex = 47;
            // 
            // btnContinue
            // 
            this.btnContinue.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnContinue.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray;
            this.btnContinue.FlatAppearance.BorderSize = 0;
            this.btnContinue.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btnContinue.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnContinue.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnContinue.Font = new System.Drawing.Font("Segoe UI Light", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContinue.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnContinue.Location = new System.Drawing.Point(36, 365);
            this.btnContinue.Name = "btnContinue";
            this.btnContinue.Size = new System.Drawing.Size(83, 29);
            this.btnContinue.TabIndex = 36;
            this.btnContinue.Text = "Continue";
            this.btnContinue.UseVisualStyleBackColor = false;
            this.btnContinue.Click += new System.EventHandler(this.btnContinue_Click);
            // 
            // numOfAdults
            // 
            this.numOfAdults.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.numOfAdults.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.numOfAdults.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.numOfAdults.Location = new System.Drawing.Point(178, 207);
            this.numOfAdults.Name = "numOfAdults";
            this.numOfAdults.Size = new System.Drawing.Size(34, 16);
            this.numOfAdults.TabIndex = 41;
            this.numOfAdults.ValueChanged += new System.EventHandler(this.numOfAdults_ValueChanged);
            // 
            // NoOfChildren
            // 
            this.NoOfChildren.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.NoOfChildren.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.NoOfChildren.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.NoOfChildren.Location = new System.Drawing.Point(178, 229);
            this.NoOfChildren.Name = "NoOfChildren";
            this.NoOfChildren.Size = new System.Drawing.Size(34, 16);
            this.NoOfChildren.TabIndex = 42;
            this.NoOfChildren.ValueChanged += new System.EventHandler(this.NoOfChildren_ValueChanged);
            // 
            // NoOfToddlers
            // 
            this.NoOfToddlers.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.NoOfToddlers.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.NoOfToddlers.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.NoOfToddlers.Location = new System.Drawing.Point(178, 255);
            this.NoOfToddlers.Name = "NoOfToddlers";
            this.NoOfToddlers.Size = new System.Drawing.Size(34, 16);
            this.NoOfToddlers.TabIndex = 43;
            this.NoOfToddlers.ValueChanged += new System.EventHandler(this.NoOfToddlers_ValueChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label8.Location = new System.Drawing.Point(34, 252);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(97, 15);
            this.label8.TabIndex = 46;
            this.label8.Text = "Toddlers (0-3yrs)";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI Semibold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(20, 20);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(206, 30);
            this.label5.TabIndex = 35;
            this.label5.Text = "Create new booking";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label7.Location = new System.Drawing.Point(33, 230);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(101, 15);
            this.label7.TabIndex = 45;
            this.label7.Text = "Children (3-12yrs)";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(33, 59);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(183, 15);
            this.label4.TabIndex = 34;
            this.label4.Text = "Please enter the following details:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label6.Location = new System.Drawing.Point(34, 208);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(87, 15);
            this.label6.TabIndex = 44;
            this.label6.Text = "Adults (12+yrs)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(33, 95);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 15);
            this.label2.TabIndex = 37;
            this.label2.Text = "Check in:";
            // 
            // dateTimeCheckIN
            // 
            this.dateTimeCheckIN.CalendarMonthBackground = System.Drawing.SystemColors.ButtonHighlight;
            this.dateTimeCheckIN.Font = new System.Drawing.Font("Segoe UI Light", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimeCheckIN.Location = new System.Drawing.Point(36, 120);
            this.dateTimeCheckIN.Name = "dateTimeCheckIN";
            this.dateTimeCheckIN.Size = new System.Drawing.Size(135, 22);
            this.dateTimeCheckIN.TabIndex = 40;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(33, 177);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(138, 15);
            this.label3.TabIndex = 38;
            this.label3.Text = "Select number of guests:";
            // 
            // ucCreateBooking01
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel1);
            this.Name = "ucCreateBooking01";
            this.Size = new System.Drawing.Size(721, 529);
            this.panel1.ResumeLayout(false);
            this.panel1CreateBooking.ResumeLayout(false);
            this.panel1CreateBooking.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.totalRooms)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numOfAdults)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NoOfChildren)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NoOfToddlers)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown NoOfToddlers;
        private System.Windows.Forms.NumericUpDown NoOfChildren;
        private System.Windows.Forms.NumericUpDown numOfAdults;
        private System.Windows.Forms.DateTimePicker dateTimeCheckIN;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnContinue;
        private System.Windows.Forms.Panel panel1CreateBooking;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.DateTimePicker dateTimeCheckOut;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.NumericUpDown totalRooms;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox GetHotelName;
    }
}
