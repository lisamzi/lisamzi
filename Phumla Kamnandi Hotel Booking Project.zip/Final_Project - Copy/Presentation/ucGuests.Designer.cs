﻿namespace PhumlaKamnandiMockup.UserControls
{
    partial class ucGuests
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelGuests = new System.Windows.Forms.Panel();
            this.gpbGuestsButtons = new System.Windows.Forms.GroupBox();
            this.btnViewGuestDetails = new System.Windows.Forms.Button();
            this.btnViewGuests = new System.Windows.Forms.Button();
            this.btnCreateGuestProfile = new System.Windows.Forms.Button();
            this.panelGuests.SuspendLayout();
            this.gpbGuestsButtons.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelGuests
            // 
            this.panelGuests.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panelGuests.Controls.Add(this.gpbGuestsButtons);
            this.panelGuests.Location = new System.Drawing.Point(0, 0);
            this.panelGuests.Name = "panelGuests";
            this.panelGuests.Size = new System.Drawing.Size(1442, 1017);
            this.panelGuests.TabIndex = 1;
            // 
            // gpbGuestsButtons
            // 
            this.gpbGuestsButtons.Controls.Add(this.btnViewGuestDetails);
            this.gpbGuestsButtons.Controls.Add(this.btnViewGuests);
            this.gpbGuestsButtons.Controls.Add(this.btnCreateGuestProfile);
            this.gpbGuestsButtons.Location = new System.Drawing.Point(38, 38);
            this.gpbGuestsButtons.Margin = new System.Windows.Forms.Padding(6);
            this.gpbGuestsButtons.Name = "gpbGuestsButtons";
            this.gpbGuestsButtons.Padding = new System.Windows.Forms.Padding(6);
            this.gpbGuestsButtons.Size = new System.Drawing.Size(1368, 558);
            this.gpbGuestsButtons.TabIndex = 2;
            this.gpbGuestsButtons.TabStop = false;
            // 
            // btnViewGuestDetails
            // 
            this.btnViewGuestDetails.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnViewGuestDetails.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnViewGuestDetails.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnViewGuestDetails.FlatAppearance.MouseOverBackColor = System.Drawing.Color.CornflowerBlue;
            this.btnViewGuestDetails.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnViewGuestDetails.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewGuestDetails.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnViewGuestDetails.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnViewGuestDetails.Location = new System.Drawing.Point(40, 267);
            this.btnViewGuestDetails.Margin = new System.Windows.Forms.Padding(6);
            this.btnViewGuestDetails.Name = "btnViewGuestDetails";
            this.btnViewGuestDetails.Size = new System.Drawing.Size(336, 81);
            this.btnViewGuestDetails.TabIndex = 9;
            this.btnViewGuestDetails.Text = "View Guest Details";
            this.btnViewGuestDetails.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnViewGuestDetails.UseVisualStyleBackColor = false;
            this.btnViewGuestDetails.Click += new System.EventHandler(this.btnViewGuestDetails_Click);
            // 
            // btnViewGuests
            // 
            this.btnViewGuests.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnViewGuests.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnViewGuests.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnViewGuests.FlatAppearance.MouseOverBackColor = System.Drawing.Color.CornflowerBlue;
            this.btnViewGuests.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnViewGuests.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewGuests.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnViewGuests.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnViewGuests.Location = new System.Drawing.Point(40, 56);
            this.btnViewGuests.Margin = new System.Windows.Forms.Padding(6);
            this.btnViewGuests.Name = "btnViewGuests";
            this.btnViewGuests.Size = new System.Drawing.Size(336, 83);
            this.btnViewGuests.TabIndex = 6;
            this.btnViewGuests.Text = "View Guests";
            this.btnViewGuests.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnViewGuests.UseVisualStyleBackColor = false;
            this.btnViewGuests.Click += new System.EventHandler(this.btnViewGuests_Click);
            // 
            // btnCreateGuestProfile
            // 
            this.btnCreateGuestProfile.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnCreateGuestProfile.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnCreateGuestProfile.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnCreateGuestProfile.FlatAppearance.MouseOverBackColor = System.Drawing.Color.CornflowerBlue;
            this.btnCreateGuestProfile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCreateGuestProfile.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCreateGuestProfile.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnCreateGuestProfile.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnCreateGuestProfile.Location = new System.Drawing.Point(40, 162);
            this.btnCreateGuestProfile.Margin = new System.Windows.Forms.Padding(6);
            this.btnCreateGuestProfile.Name = "btnCreateGuestProfile";
            this.btnCreateGuestProfile.Size = new System.Drawing.Size(336, 77);
            this.btnCreateGuestProfile.TabIndex = 7;
            this.btnCreateGuestProfile.Text = "Create Guest Profile";
            this.btnCreateGuestProfile.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCreateGuestProfile.UseVisualStyleBackColor = false;
            this.btnCreateGuestProfile.Click += new System.EventHandler(this.btnCreateGuestProfile_Click);
            // 
            // ucGuests
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panelGuests);
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "ucGuests";
            this.Size = new System.Drawing.Size(1442, 1017);
            this.panelGuests.ResumeLayout(false);
            this.gpbGuestsButtons.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelGuests;
        private System.Windows.Forms.GroupBox gpbGuestsButtons;
        private System.Windows.Forms.Button btnViewGuestDetails;
        private System.Windows.Forms.Button btnViewGuests;
        private System.Windows.Forms.Button btnCreateGuestProfile;
    }
}
