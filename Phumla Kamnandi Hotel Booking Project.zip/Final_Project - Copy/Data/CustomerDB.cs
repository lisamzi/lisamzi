﻿using PhumlaKamnandiMockup.Business;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace PhumlaKamnandiMockup.Data
{
    public class CustomerDB
    {
        private Collection<Customer> collectionOfCustomers;
        private string _connectionString = Properties.Settings.Default.Phumla_KConnectionString;//"Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\DELL\\OneDrive\\Desktop\\FinalPhumla\\Final_Project\\PhumlaK_Hotel.mdf;Integrated Security=True;Connect Timeout=30";
        public void addToCollection()
        {
            Customer customertoAdd = null;
            
            collectionOfCustomers = new Collection<Customer>(); 
            string selectquery = "SELECT * FROM Customer";

            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                SqlCommand command = new SqlCommand(selectquery, connection);
                connection.Open();

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    
                    while (reader.Read())
                    {
                        customertoAdd = new Customer
                        (
                            reader["CustID"].ToString(),
                            reader["Name"].ToString(),
                            reader["Surname"].ToString(),
                            reader["Email"].ToString(),
                            reader["Age"] == DBNull.Value ? 0 : Convert.ToInt32(reader["Age"]), 
                            reader["Phone"].ToString(),
                            reader["Address"].ToString()
                        );

                        this.collectionOfCustomers.Add(customertoAdd); 
                    }
                }
            }
        }

        public Collection<Customer> GetAllGuests()
        {
            Collection<Customer> guests = new Collection<Customer>();
            string selectQuery = "SELECT CustID, Name, Surname, Email, Phone, Address, Age FROM Customer ORDER BY CustID";

            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                SqlCommand command = new SqlCommand(selectQuery, connection);
                connection.Open();

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Customer guest = new Customer
                        (
                            reader["CustID"].ToString(),
                            reader["Name"].ToString(),
                            reader["Surname"].ToString(),
                            reader["Email"].ToString(),
                            reader["Age"] == DBNull.Value ? 0 : Convert.ToInt32(reader["Age"]), 
                            reader["Phone"].ToString(),
                            reader["Address"].ToString()
                        );

                        guests.Add(guest);
                    }
                }
            }

            return guests; 
        }

        public string GetGuestNameByCustID(string custID)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                string query = "SELECT Name FROM Customer WHERE CustID = @CustID";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@CustID", custID);
                    var result = command.ExecuteScalar();

                    //make sure guest name not null
                    return result != null ? result.ToString() : null;
                }
            }
        }

        public Customer GetCustomerById(string custID)
        {
            Customer customer = null;

            
            string query = "SELECT CustID, Name, Surname, Email, Phone, Address, Age FROM Customer WHERE CustID = @CustID";

            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@CustID", custID);

                connection.Open();

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    if (reader.Read()) //read record in database
                    {
                        customer = new Customer
                        (
                            reader["CustID"].ToString(),
                            reader["Name"].ToString(),
                            reader["Surname"].ToString(),
                            reader["Email"].ToString(),
                            reader["Age"] == DBNull.Value ? 0 : Convert.ToInt32(reader["Age"]), //handle null age
                            reader["Phone"].ToString(),
                            reader["Address"].ToString()
                        );
                    }
                }
            }

            return customer; 
        }

        public string GenerateCustID(string name)
        {
            string initials = string.Join("", name.Split(' ', (char)StringSplitOptions.RemoveEmptyEntries).Select(n => n[0]));

            Random random = new Random();
            string newCustID;

            do
            {
                //generate random number and custId that doesn't already exists.
                int randomNumber = random.Next(1000, 9999);
                newCustID = $"{initials.ToUpper()}{randomNumber}";

                
            } while (DoesCustomerIDExists(newCustID)); //keep generating custID until it doesnt exists.

            return newCustID;
        }
        public bool DoesCustomerIDExists(string custID)
        {
            bool exists = false;

            string query = "SELECT COUNT(*) FROM Customer WHERE CustID = @CustID";

            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@CustID", custID);

                connection.Open();

                int count = (int)command.ExecuteScalar(); // ExecuteScalar returns the first column of the first row
                exists = (count > 0); // If count > 0, the ID exists
            }

            return exists;
        }

        private int CalculateAge(DateTime dateOfBirth)
        {
            int age = DateTime.Now.Year - dateOfBirth.Year;
            if (DateTime.Now.DayOfYear < dateOfBirth.DayOfYear)
            {
                age--;
            }
            return age;
        }

        public void UpdateGuest(Customer guest)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                string query = "UPDATE Customer SET Name = @Name, Surname = @Surname, Email = @Email, Phone = @Phone, Address = @Address WHERE CustID = @GuestID";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@GuestID", guest.CustID);
                cmd.Parameters.AddWithValue("@Name", guest.Name);
                cmd.Parameters.AddWithValue("@Surname", guest.Surname);
                cmd.Parameters.AddWithValue("@Email", guest.Email);
                cmd.Parameters.AddWithValue("@Phone", guest.Phone);
                cmd.Parameters.AddWithValue("@Address", guest.Address);

                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }


        public void AddGuest(Customer guest)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                string query = "INSERT INTO Customer (CustID, GuestName, GuestLName, Email, ContactNumber, Age, Address) " +
 "VALUES (@CustID, @Name, @Surname, @Email, @Phone, @Age, @Address)";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@CustID", guest.CustID);
                cmd.Parameters.AddWithValue("@Name", guest.Name);
                cmd.Parameters.AddWithValue("@Surname", guest.Surname);
                cmd.Parameters.AddWithValue("@Email", guest.Email);
                cmd.Parameters.AddWithValue("@Phone", guest.Phone);
                cmd.Parameters.AddWithValue("@Age", guest.Age);
                cmd.Parameters.AddWithValue("@Address", guest.Address);

                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }
        public void SaveGuest(Customer customer)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                string query = @"
        INSERT INTO Customer (CustID, Name, Surname, Email, Phone, Address, Age)
        VALUES (@CustID, @Name, @Surname, @Email, @Phone, @Address, @Age)";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                   
                    command.Parameters.AddWithValue("@CustID", customer.CustID);
                    command.Parameters.AddWithValue("@Name", customer.Name);
                    command.Parameters.AddWithValue("@Surname", customer.Surname);
                    command.Parameters.AddWithValue("@Email", customer.Email);
                    command.Parameters.AddWithValue("@Phone", customer.Phone);
                    command.Parameters.AddWithValue("@Address", customer.Address);
                    command.Parameters.AddWithValue("@Age", customer.Age);

                 
                    command.ExecuteNonQuery();
                }
            }
        }
        public void DeleteGuest(string custID)
        {
            string query = "DELETE FROM Customer WHERE CustID = @CustID";

            try
            {
                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@CustID", custID);

                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected == 0)
                    {
                        MessageBox.Show("No rows were affected. The guest could not be deleted. It may not exist.", "Guest Not Deleted", MessageBoxButtons.OK);
                    }
                    else
                    {
                        MessageBox.Show("Guest successfully deleted.", "Success", MessageBoxButtons.OK);
                    }
                }
            }
            catch (SqlException sqlEx)
            {
                MessageBox.Show($"SQL Error: {sqlEx.Message}", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "General Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }




    }
}
