﻿using PhumlaKamnandiMockup.Business;
using PhumlaKamnandiMockup.Data;
using System;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.SqlClient;
using System.Runtime.Remoting.Contexts;
using System.Windows.Forms;
using PhumlaKamnandiMockup.UserControls;

namespace PhumlaKamnandiMockup.Data
{
    public class BookingsDB : DB
    {
        #region Data members
        private string table = "Bookings";
        private string sqlLocal1 = "SELECT * FROM Bookings";
        private Collection<Booking> booking;
        public string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\DELL\\OneDrive\\Desktop\\Final_Project\\Final_Project\\PhumlaK_Hotel.mdf;Integrated Security = True; Connect Timeout = 30";//"Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\DELL\\OneDrive\\Desktop\\FinalPhumla\\Final_Project\\PhumlaK_Hotel.mdf;Integrated Security=True;Connect Timeout=30";
        #endregion

        #region Property Method: Collection
        public Collection<Booking> Allbookings
        {
            get
            {
                return booking;
            }
        }
        #endregion
        #region constructor
        public BookingsDB() : base()
        {
            booking = new Collection<Booking>();
            FillDataSet(sqlLocal1, table);
        }
        #endregion
        #region Utility Methods

        public DataSet GetDataSet()
        {
            return dsMain;
        }
        private void Add2Collection(string table)
        {
            DataRow myRow = null;


            //loop through each DataRow in the dataset table
            foreach (DataRow myRow_loopVariable in dsMain.Tables[table].Rows)
            {
                myRow = myRow_loopVariable;

                //skip rows that have been marked as deleted
                if (!(myRow.RowState == DataRowState.Deleted))
                {
                    //instantiate a new Booking object
                    Booking aBooking = new Booking();

                    //obtain each booking attribute from the specific field in the row in the table
                    aBooking.BookingID = Convert.ToString(myRow["BookingID"]);      
                    aBooking.CustID = Convert.ToString(myRow["CustID"]);             
                    aBooking.HotelID = Convert.ToString(myRow["HotelID"]);           
                    aBooking.CheckInDate = Convert.ToDateTime(myRow["CheckInDate"]); 
                    aBooking.CheckOutDate = Convert.ToDateTime(myRow["CheckOutDate"]);
                    aBooking.Status = Convert.ToString(myRow["Status"]);             
                    aBooking.NoOfGuests = Convert.ToInt32(myRow["NoOfGuests"]);
                    aBooking.NoOfRooms = Convert.ToInt32(myRow["NoOfRooms"]);
                    aBooking.TotalAmount = Convert.ToInt32(myRow["TotalAmount"]);


                    //add the new Booking object to the bookings collection
                    booking.Add(aBooking);
                }
            }
        }

        public List<Booking> GetAllBookings()
        {
            List<Booking> bookings = new List<Booking>();

            string query = "SELECT * FROM Bookings";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    Booking booking = new Booking
                    {
                        BookingID = reader["BookingID"].ToString(),
                        CustID = reader["CustID"].ToString(),
                        HotelID = reader["HotelID"].ToString(),
                        CheckInDate = (DateTime)reader["CheckInDate"],
                        CheckOutDate = (DateTime)reader["CheckOutDate"],
                        Status = reader["Status"].ToString(),

                        // Provide default values for nullable fields
                        NoOfGuests = reader["NoOfGuests"] != DBNull.Value ? (int)reader["NoOfGuests"] : 0,
                        NoOfRooms = reader["NoOfRooms"] != DBNull.Value ? (int)reader["NoOfRooms"] : 0,
                        TotalAmount = reader["TotalAmount"] != DBNull.Value ? (decimal)reader["TotalAmount"] : 0m,
                        
                        
                    };

                    bookings.Add(booking);
                }
            }

            return bookings;
        }



        private int FindRow(Booking aBooking, string table)
        {
            int rowIndex = 0;
            DataRow myRow;
            int returnValue = -1;  

            
            foreach (DataRow myRow_loopVariable in dsMain.Tables[table].Rows)
            {
                myRow = myRow_loopVariable;

                
                if (myRow.RowState != DataRowState.Deleted)
                {
                    
                    if (aBooking.BookingID == Convert.ToString(dsMain.Tables[table].Rows[rowIndex]["BookingID"]))
                    {
                        returnValue = rowIndex;  
                        break;  
                    }
                    rowIndex++;  
                }
            }
            return returnValue;  
        }

        private void FillRow(DataRow AdataRow, Booking Abooking, DB.DBOperation dBOperation)
        {
            
            switch (dBOperation)
            {
                case DB.DBOperation.Add:
                    
                    AdataRow["BookingID"] = Abooking.BookingID;         
                    AdataRow["CustID"] = Abooking.CustID;                 
                    AdataRow["HotelID"] = Abooking.HotelID;              
                    AdataRow["CheckInDate"] = Abooking.CheckInDate;       
                    AdataRow["CheckOutDate"] = Abooking.CheckOutDate;    
                    AdataRow["Status"] = Abooking.Status;                 
                    AdataRow["NoOfGuests"] = Abooking.NoOfGuests;
                    AdataRow["NoOfGuests"] = Abooking.NoOfGuests;        
                    AdataRow["NoOfRooms"] = Abooking.NoOfRooms;           
                    AdataRow["TotalAmount"] = Abooking.TotalAmount;
                    break;

                case DB.DBOperation.Edit:
                    
                    AdataRow["BookingID"] = Abooking.BookingID;           
                    AdataRow["CustID"] = Abooking.CustID;
                    AdataRow["HotelID"] = Abooking.HotelID;
                    AdataRow["CheckInDate"] = Abooking.CheckInDate;
                    AdataRow["CheckOutDate"] = Abooking.CheckOutDate;
                    AdataRow["Status"] = Abooking.Status;
                    AdataRow["NoOfGuests"] = Abooking.NoOfGuests;
                    AdataRow["NoOfGuests"] = Abooking.NoOfGuests;         
                    AdataRow["NoOfRooms"] = Abooking.NoOfRooms;           
                    AdataRow["TotalAmount"] = Abooking.TotalAmount;
                    break;

                case DB.DBOperation.Delete:
                    
                    AdataRow.Delete();
                    break;
            }
        }

        #endregion

        #region DataBase Operations CRUD

        public void DataSetChange(Booking booking ,DB.DBOperation operation)
        {
            DataRow aRow = null;
            string dataTable = table;

            switch (operation)
            {
                //adding to the dataset
                case DBOperation.Add:
                    aRow = dsMain.Tables[dataTable].NewRow();
                    break;


                //editing the dataset
                case DBOperation.Edit:
                    aRow = dsMain.Tables[dataTable].Rows[FindRow(booking, dataTable)];

                    FillRow(aRow, booking, DBOperation.Edit);
                    break;


            }
        }
        #endregion
        #region Build Parameters Create commands and update database
        private void Create_INSERT_Command(Booking aBooking)
        {
            //set up the insert command for the Bookings table
            daMain.InsertCommand = new SqlCommand("INSERT into Bookings (BookingID, CustID, HotelID, CheckInDate, CheckOutDate, Status, NoOfGuests, NoOfRooms, TotalAmount) VALUES (@BookingID, @CustID, @HotelID, @CheckInDate, @CheckOutDate, @Status, @NoOfGuests, @NoOfRooms, @TotalAmount)", cnMain);

            Build_INSERT_Parameters(aBooking);
        }

        private void Build_INSERT_Parameters(Booking aBooking)
        {
            if (aBooking == null)
            {
                throw new ArgumentNullException(nameof(aBooking), "Booking cannot be null.");
            }

            //create SQL Parameters and associate them with the command
            SqlParameter param;

            param = new SqlParameter("@BookingID", SqlDbType.NVarChar, 10);
            param.Value = aBooking.BookingID;
            daMain.InsertCommand.Parameters.Add(param);

            param = new SqlParameter("@CustID", SqlDbType.NVarChar, 10);
            param.Value = aBooking.CustID;
            daMain.InsertCommand.Parameters.Add(param);

            param = new SqlParameter("@HotelID", SqlDbType.NVarChar, 10);
            param.Value = aBooking.HotelID;
            daMain.InsertCommand.Parameters.Add(param);

            param = new SqlParameter("@CheckInDate", SqlDbType.DateTime);
            param.Value = aBooking.CheckInDate;
            daMain.InsertCommand.Parameters.Add(param);

            param = new SqlParameter("@CheckOutDate", SqlDbType.DateTime);
            param.Value = aBooking.CheckOutDate;
            daMain.InsertCommand.Parameters.Add(param);

            param = new SqlParameter("@Status", SqlDbType.NVarChar, 50);
            param.Value = aBooking.Status;
            daMain.InsertCommand.Parameters.Add(param);

            param = new SqlParameter("@NoOfGuests", SqlDbType.Int);
            param.Value = aBooking.NoOfGuests;
            daMain.InsertCommand.Parameters.Add(param);

            param = new SqlParameter("@NoOfRooms", SqlDbType.Int);
            param.Value = aBooking.NoOfRooms;
            daMain.InsertCommand.Parameters.Add(param);

            param = new SqlParameter("@TotalAmount", SqlDbType.Decimal);
            param.Value = aBooking.TotalAmount; //make sure TotalAmount is properly assigned
            daMain.InsertCommand.Parameters.Add(param);
        }
        private void Build_UPDATE_Parameters(Booking aBooking)
        {
            SqlParameter param;

            //booking details
            param = new SqlParameter("@CustID", SqlDbType.NVarChar, 10, "CustID");
            param.SourceVersion = DataRowVersion.Current;
            daMain.UpdateCommand.Parameters.Add(param);

            param = new SqlParameter("@HotelID", SqlDbType.NVarChar, 10, "HotelID");
            param.SourceVersion = DataRowVersion.Current;
            daMain.UpdateCommand.Parameters.Add(param);

            param = new SqlParameter("@CheckInDate", SqlDbType.DateTime, 0, "CheckInDate");
            param.SourceVersion = DataRowVersion.Current;
            daMain.UpdateCommand.Parameters.Add(param);

            param = new SqlParameter("@CheckOutDate", SqlDbType.DateTime, 0, "CheckOutDate");
            param.SourceVersion = DataRowVersion.Current;
            daMain.UpdateCommand.Parameters.Add(param);

            param = new SqlParameter("@Status", SqlDbType.NVarChar, 50, "Status");
            param.SourceVersion = DataRowVersion.Current;
            daMain.UpdateCommand.Parameters.Add(param);

            param = new SqlParameter("@NoOfGuests", SqlDbType.Int, 0, "NoOfGuests");
            param.SourceVersion = DataRowVersion.Current;
            daMain.UpdateCommand.Parameters.Add(param);

            
            param = new SqlParameter("@Original_BookingID", SqlDbType.NVarChar, 10, "BookingID");
            param.SourceVersion = DataRowVersion.Original;
            daMain.UpdateCommand.Parameters.Add(param);
            param = new SqlParameter("@NoOfRooms", SqlDbType.Int, 0, "NoOfRooms");
            param.SourceVersion = DataRowVersion.Current;
            daMain.UpdateCommand.Parameters.Add(param);

            param = new SqlParameter("@TotalAmount", SqlDbType.Decimal, 0, "TotalAmount");
            param.SourceVersion = DataRowVersion.Current;
            daMain.UpdateCommand.Parameters.Add(param);

            param = new SqlParameter("@Original_BookingID", SqlDbType.NVarChar, 10, "BookingID");
            param.SourceVersion = DataRowVersion.Original;
            daMain.UpdateCommand.Parameters.Add(param);
        }
        private void Create_UPDATE_Command(Booking aBooking)
        {
            daMain.UpdateCommand = new SqlCommand(
                "UPDATE Bookings SET CustID = @CustID, HotelID = @HotelID, CheckInDate = @CheckInDate, " +
                "CheckOutDate = @CheckOutDate, Status = @Status, NoOfGuests = @NoOfGuests, NoOfRooms = @NoOfRooms, TotalAmount = @TotalAmount " +
                "WHERE BookingID = @Original_BookingID", cnMain);

            Build_UPDATE_Parameters(aBooking);
        }
        public bool UpdateDataSource(Booking aBooking)
        {
            if (aBooking == null)
            {
                throw new ArgumentNullException(nameof(aBooking), "Booking cannot be null.");
            }

            bool success = true;
            Create_INSERT_Command(aBooking);
            Create_UPDATE_Command(aBooking);

            success = UpdateDataSource(sqlLocal1, table);

            return success;
        }


        #endregion

        public int adults;
        public int children;
        public int toddlers;

        //generate booking ID
        public static string GenerateBookingID(string connectionString)
        {
            string newBookingID = "B001"; //if no bookings exist

            string query = "SELECT MAX(BookingID) FROM Bookings WHERE BookingID LIKE 'B%'";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                object result = command.ExecuteScalar();

                if (result != DBNull.Value)
                {
                    string maxBookingID = result.ToString();
                    string numberPart = maxBookingID.Substring(1); //skip 'B'
                    int number = int.Parse(numberPart);
                    number++; // increment

                    newBookingID = "B" + number.ToString("D3"); //format 
                }
            }

            return newBookingID;
        }


       
        public bool CheckRoomAvailability(int requiredRooms, DateTime checkIn, DateTime checkOut)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT COUNT(*) FROM Bookings WHERE CheckInDate < @CheckOut AND CheckOutDate > @CheckIn";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@CheckOut", checkOut);
                    command.Parameters.AddWithValue("@CheckIn", checkIn);

                    int bookedRooms = (int)command.ExecuteScalar();
                    const int totalRooms = 20;

                    return (bookedRooms + requiredRooms) <= totalRooms;
                }
            }
        }


        //adding method to database method
        //create the booking in the database
        public string CreateBooking(Booking booking)
        {
            string bookingID = GenerateBookingID(connectionString); // ensure this method generates and returns a valid ID
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string bookingQuery = "INSERT INTO Bookings (BookingID, CustID, HotelID, CheckInDate, CheckOutDate, Status, NoOfGuests, NoOfRooms, TotalAmount) " +
                                      "VALUES (@BookingID, @CustID, @HotelID, @CheckInDate, @CheckOutDate, @Status, @NoOfGuests, @NoOfRooms, @TotalAmount)";

                SqlCommand cmd = new SqlCommand(bookingQuery, connection);
                cmd.Parameters.AddWithValue("@BookingID", bookingID); // use the generated bookingID
                cmd.Parameters.AddWithValue("@CustID", booking.CustID);
                cmd.Parameters.AddWithValue("@HotelID", booking.HotelID);
                cmd.Parameters.AddWithValue("@CheckInDate", booking.CheckInDate);
                cmd.Parameters.AddWithValue("@CheckOutDate", booking.CheckOutDate);
                cmd.Parameters.AddWithValue("@Status", booking.Status);
                cmd.Parameters.AddWithValue("@NoOfGuests", booking.NoOfGuests);
                cmd.Parameters.AddWithValue("@NoOfRooms", booking.NoOfRooms);
                cmd.Parameters.AddWithValue("@TotalAmount", booking.TotalAmount);

                connection.Open();
                int rowsAffected = cmd.ExecuteNonQuery();
                if (rowsAffected == 0)
                {
                    throw new Exception("No rows were affected. The booking could not be added.");
                }
            }

            return bookingID; //return the generated BookingID
        }


        //add booking to db

        public string AddBooking(Booking newBooking)
        {
            //validate the booking object
            if (newBooking == null)
            {
                throw new ArgumentNullException(nameof(newBooking), "Booking cannot be null.");
            }

            //call CreateBooking and store the returned BookingID
            string bookingID = CreateBooking(newBooking); //this should be a string return

            //optionally refresh the booking collection
            booking.Add(newBooking);

            return bookingID; //return the BookingID
        }






        public Booking GetBookingByID(string bookingID)
        {
            Booking booking = null;
            string query = "SELECT * FROM Bookings WHERE BookingID = @BookingID";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@BookingID", bookingID);

                connection.Open();

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    if (reader.Read()) 
                    {
                        string custID = reader["CustID"].ToString();

                        CustomerDB customerDB = new CustomerDB();

                        
                        Customer customer = customerDB.GetCustomerById(custID);

                        booking = new Booking
                         (
                            bookingID,
                            custID,
                            reader["HotelID"].ToString(),
                            Convert.ToDateTime(reader["CheckInDate"]),
                            Convert.ToDateTime(reader["CheckOutDate"]),
                            reader["Status"].ToString(),
                            Convert.ToInt32(reader["NoOfGuests"]),
                            Convert.ToInt32(reader["NoOfRooms"]), 
                            Convert.ToDecimal(reader["TotalAmount"]) 
                         );

                    }
                    else
                    {
                        
                        MessageBox.Show("Booking not found", "The booking has not been found.", MessageBoxButtons.OK);
                    }
                }
            }

            return booking;
        }


        private List<RoomAllocations> GetRoomAllocationsForBooking(string bookingID)
        {

            return new List<RoomAllocations>();
        }


        //cancel a booking
        public void CancelBooking(string bookingID, string reasonForCancellation)
        {
            string query = "UPDATE Bookings SET Status = 'Canceled', CancellationDate = @CancellationDate, ReasonForCancellation = @ReasonForCancellation " +
                           "WHERE BookingID = @BookingID";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@BookingID", bookingID);
                command.Parameters.AddWithValue("@CancellationDate", DateTime.Now);
                command.Parameters.AddWithValue("@ReasonForCancellation", reasonForCancellation);

                connection.Open();
                command.ExecuteNonQuery();
            }
        }




        public void DeleteBooking(string bookingID)
        {
            string query = "DELETE FROM Bookings WHERE BookingID = @BookingID";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@BookingID", bookingID);

                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected == 0)
                    {
                        MessageBox.Show("No rows were affected. The booking could not be deleted. It may have already been deleted or does not exist.", "Booking Not Deleted", MessageBoxButtons.OK);
                    }
                    else
                    {
                        MessageBox.Show("Booking successfully deleted.", "Success", MessageBoxButtons.OK);
                    }
                }
            }
            catch (SqlException sqlEx)
            {
                MessageBox.Show($"SQL Error: {sqlEx.Message}", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "General Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        //method to update booking
        public bool UpdateBooking(string bookingId, int noOfGuests, DateTime checkIn, DateTime checkOut, decimal totalAmount, int noOfRooms)
        {
            // Prepare the SQL query for updating the booking
            string query = "UPDATE Bookings SET " +
                           "NoOfGuests = @NoOfGuests, " +
                           "CheckInDate = @CheckInDate, " +
                           "CheckOutDate = @CheckOutDate, " +
                           "TotalAmount = @TotalAmount, " +
                           "NoOfRooms = @NoOfRooms " +
                           "WHERE BookingID = @BookingID";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);

                // Add parameters
                command.Parameters.AddWithValue("@NoOfGuests", noOfGuests);
                command.Parameters.AddWithValue("@CheckInDate", checkIn);
                command.Parameters.AddWithValue("@CheckOutDate", checkOut);
                command.Parameters.AddWithValue("@TotalAmount", totalAmount);
                command.Parameters.AddWithValue("@NoOfRooms", noOfRooms);
                command.Parameters.AddWithValue("@BookingID", bookingId); // Use the BookingID for the WHERE clause

                connection.Open();
                int rowsAffected = command.ExecuteNonQuery();

                // Check if any rows were affected
                return rowsAffected > 0; // Return true if the update was successful
            }
        }


        // Method to fetch booking by ID (to be implemented)
        private Booking GetBookingById(int bookingID)
        {
            // Prepare the SQL query to get the existing booking
            string query = "SELECT * FROM Bookings WHERE BookingID = @BookingID";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@BookingID", bookingID);

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    // Create and return a Booking object with existing values
                    return new Booking
                    {
                        BookingID = (string)reader["BookingID"],
                        CustID = (string)reader["CustID"],
                        HotelID = (string)reader["HotelID"],
                        CheckInDate = (DateTime)reader["CheckInDate"],
                        CheckOutDate = (DateTime)reader["CheckOutDate"],
                        Status = (string)reader["Status"],
                        NoOfGuests = (int)reader["NoOfGuests"],
                        NoOfRooms = (int)reader["NoOfRooms"],
                          // Assuming this field exists
                        TotalAmount = (decimal)reader["TotalAmount"]
                    };
                }
                return null; // Return null if no booking is found
            }
        }
        public bool BookingExists(string bookingID)
    {
        if (string.IsNullOrEmpty(bookingID))
        {
            throw new ArgumentNullException(nameof(bookingID), "Booking ID cannot be null or empty.");
        }

        string query = "SELECT COUNT(1) FROM Bookings WHERE BookingID = @BookingID";

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@BookingID", bookingID);

            connection.Open();
            int count = (int)command.ExecuteScalar();

            return count > 0; // Return true if booking exists
        }
    }

        public void AddCancelledBooking(string bookingID, string reasonForCancellation, DateTime dateOfCancellation)
        {
            string query = "INSERT INTO Cancellation (BookingID, ReasonForCancellation, DateOfCancellation) " +
                           "VALUES (@BookingID, @ReasonForCancellation, @DateOfCancellation)";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@BookingID", bookingID);
                    command.Parameters.AddWithValue("@ReasonForCancellation", reasonForCancellation);
                    command.Parameters.AddWithValue("@DateOfCancellation", dateOfCancellation.ToString("yyyy-MM-dd"));

                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected == 0)
                    {
                        MessageBox.Show("No rows were affected. The canceled booking could not be added.", "Booking not added", MessageBoxButtons.OK);
                    }
                    else
                    {
                        MessageBox.Show("The booking has been successfully added to the cancellation record.", "Success", MessageBoxButtons.OK);
                    }
                }
            }
            catch (SqlException sqlEx)
            {
                // Check for specific error codes that indicate the booking is not found
                if (sqlEx.Number == 547) // Foreign key violation
                {
                    MessageBox.Show("The booking has already been deleted or does not exist.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    //MessageBox.Show($"SQL Error: {sqlEx.Message}", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "General Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

    }

}



