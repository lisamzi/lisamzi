﻿using PhumlaKamnandiMockup.Business;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace PhumlaKamnandiMockup.Data
{
    public class CancellationDataAccess
    {
        private string connectionString = Properties.Settings.Default.Phumla_KConnectionString; // Adjust as needed

        // Method to get all cancellations
        public List<CancellationReport> GetAllCancellations()
        {
            List<CancellationReport> cancelledBookings = new List<CancellationReport>();

            // SQL Query to pull from Cancellation table
            string query = "SELECT BookingID, DateOfCancellation, ReasonForCancellation FROM dbo.Cancellation";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand(query, connection);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            CancellationReport report = new CancellationReport
                            {
                                BookingID = reader["BookingID"].ToString(),
                                CancellationDate = Convert.ToDateTime(reader["DateOfCancellation"]),
                                ReasonForCancellation = reader["ReasonForCancellation"].ToString()
                            };

                            cancelledBookings.Add(report);
                        }
                    }
                }
            }
            catch (SqlException sqlEx)
            {
                MessageBox.Show($"SQL Error: {sqlEx.Message}", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "General Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return cancelledBookings;
        }
    }
}
