﻿INSERT INTO [dbo].[Customer] ([CustID], [Name], [Surname], [Email], [Age], [Phone], [Address])
VALUES (N'JS1234', N'John', N'Smith', N'john.smith@example.com', 35, 1234567890, N'7 Main Rd, Rondebosch, 7700');

INSERT INTO [dbo].[Customer] ([CustID], [Name], [Surname], [Email], [Age], [Phone], [Address])
VALUES (N'NM5678', N'Nkosinathi', N'Mthembu', N'nkosinathi.m@example.com', 40, 9876543210, N'14 Lungelo Drive, Mtimkhulu, Durban, 4001');

INSERT INTO [dbo].[Customer] ([CustID], [Name], [Surname], [Email], [Age], [Phone], [Address])
VALUES (N'SJ2312', N'Sarah', N'Johnson', N'sarah.johnson@example.com', 28, 1122334455, N'123 Elm St, Cityville, 54321');

INSERT INTO [dbo].[Customer] ([CustID], [Name], [Surname], [Email], [Age], [Phone], [Address])
VALUES (N'DB9823', N'David', N'Brown', N'david.brown@example.com', 50, 2233445566, N'456 Oak St, Townsville, 67890');

INSERT INTO [dbo].[Customer] ([CustID], [Name], [Surname], [Email], [Age], [Phone], [Address])
VALUES (N'EW4932', N'Emily', N'Wilson', N'emily.wilson@example.com', 32, 3344556677, N'789 Maple St, Villageburg, 11223');

INSERT INTO [dbo].[Customer] ([CustID], [Name], [Surname], [Email], [Age], [Phone], [Address])
VALUES (N'JD2387', N'James', N'Davis', N'james.davis@example.com', 29, 4455667788, N'321 Pine St, Hamlet, 33445');

INSERT INTO [dbo].[Customer] ([CustID], [Name], [Surname], [Email], [Age], [Phone], [Address])
VALUES (N'ST4847', N'Sophia', N'Thompson', N'sophia.thompson@example.com', 24, 5566778899, N'654 Birch St, Metropolis, 55667');

INSERT INTO [dbo].[Customer] ([CustID], [Name], [Surname], [Email], [Age], [Phone], [Address])
VALUES (N'OM3892', N'Oliver', N'Martin', N'oliver.martin@example.com', 37, 6677889900, N'987 Cedar St, Springfield, 77889');

INSERT INTO [dbo].[Customer] ([CustID], [Name], [Surname], [Email], [Age], [Phone], [Address])
VALUES (N'CW4992', N'Charlotte', N'White', N'charlotte.white@example.com', 41, 7788990011, N'234 Willow St, Lakeside, 99000');

INSERT INTO [dbo].[Customer] ([CustID], [Name], [Surname], [Email], [Age], [Phone], [Address])
VALUES (N'LA1122', N'Liam', N'Anderson', N'liam.anderson@example.com', 45, 8899001122, N'567 Fir St, Riverside, 12345');
